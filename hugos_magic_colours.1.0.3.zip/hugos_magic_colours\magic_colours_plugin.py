import os
import csv
import re
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QToolBar
from qgis.PyQt.QtGui import QColor, QPixmap, QPainter, QFont, QIcon
from qgis.PyQt.QtCore import Qt, QSize, QObject, QEvent
from qgis.PyQt import sip
from qgis.core import (
    QgsRasterLayer, QgsColorRampShader, QgsRasterShader,
    QgsSingleBandPseudoColorRenderer, QgsRasterBandStats,
    QgsApplication, QgsProcessingProvider, QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer, QgsProject,
    QgsCoordinateTransform, QgsRectangle, QgsStyle, QgsRasterMinMaxOrigin,
    QgsGradientColorRamp, QgsGradientStop
)
from qgis.core import QgsVectorLayer

# ---------------------------------------------------------------------------
# Version-safe QgsRasterMinMaxOrigin enum access.
#
# QGIS has been migrating raster-related enums that used to hang directly
# off QgsRasterMinMaxOrigin into the central Qgis class (Qgis.RasterRangeExtent,
# Qgis.RasterRangeLimit). Old flat attribute access like
# QgsRasterMinMaxOrigin.WholeRaster was kept working via SIP backward-compat
# shims for a while, but that shim was removed as of QGIS 3.44, causing:
#   AttributeError: type object 'QgsRasterMinMaxOrigin' has no attribute 'WholeRaster'
#
# We resolve every value we need up front here, preferring the new Qgis.*
# location and falling back to the older QgsRasterMinMaxOrigin.Extent /
# .Limits nested-scoped form (which still works on both old and new QGIS).
#
# Note: in the new Qgis.RasterRangeExtent enum, CurrentCanvas was itself
# renamed to FixedCanvas (old name kept as a compat alias) — mapped below
# so either code path resolves to the same underlying value.
# ---------------------------------------------------------------------------
try:
    from qgis.core import Qgis
    RASTER_EXTENT_WHOLE   = Qgis.RasterRangeExtent.WholeRaster
    RASTER_EXTENT_UPDATED = Qgis.RasterRangeExtent.UpdatedCanvas
    RASTER_EXTENT_CURRENT = Qgis.RasterRangeExtent.FixedCanvas
    RASTER_LIMIT_MINMAX   = Qgis.RasterRangeLimit.MinMax
except AttributeError:
    RASTER_EXTENT_WHOLE   = QgsRasterMinMaxOrigin.Extent.WholeRaster
    RASTER_EXTENT_UPDATED = QgsRasterMinMaxOrigin.Extent.UpdatedCanvas
    RASTER_EXTENT_CURRENT = QgsRasterMinMaxOrigin.Extent.CurrentCanvas
    RASTER_LIMIT_MINMAX   = QgsRasterMinMaxOrigin.Limits.MinMax

# ---------------------------------------------------------------------------
# Supported raster file extensions
# ---------------------------------------------------------------------------
SUPPORTED_EXTENSIONS = {".tif", ".tiff", ".flt", ".asc", ".img", ".vrt", ".dem"}

# ---------------------------------------------------------------------------
# Suffix detection — order matters, longer/more specific first
# ---------------------------------------------------------------------------
DEPTH_SUFFIXES    = ["_d_max", "_d_Max", "_Max_d", "_max_d"]
VELOCITY_SUFFIXES = ["_v_max", "_v_Max", "_Max_v", "_max_v", "_V_max", "_V_Max", "_Max_V", "_max_V"]
SRC_SUFFIXES      = ["_src"]
Z0_SUFFIXES       = ["_z0","_z0_Max"]
ZAEM1_SUFFIXES    = ["_zaem1","_zaem1_Max"]
H_SUFFIXES        = ["_h","_h_Max"]
DEM_M_SUFFIXES    = ["_dem_m"]
DEM_SUFFIXES      = ["dem"]

# ---------------------------------------------------------------------------
# Depth colour scheme — breakpoints and RGBA
# Colours stay fixed; breakpoints are chosen dynamically from raster stats
# ---------------------------------------------------------------------------
DEPTH_COLOURS = [
    (242, 255, 251, 255),   # very light mint    — shallowest
    (191, 243, 176, 255),   # light green
    ( 55, 208, 238, 255),   # cyan
    ( 30, 113, 236, 255),   # mid blue
    (126,  47, 225, 255),   # purple
    ( 38,   0, 128, 255),   # deep navy          — deepest / inf
]

# Candidate breakpoint sets ordered shallow → deep
# The algorithm picks the first set where max_val <= last finite break * 1.5
DEPTH_BREAK_SETS = [
    # Very shallow (urban drainage / ponding)
    [0.1, 0.2, 0.5, 1.0, 1.5, None],
    # Shallow floods
    [0.5, 1.0, 1.5, 2.0, 2.5, None],
    # Moderate floods
    [0.5, 1.0, 2.0, 4.0, 8.0, None],
    # Deep
    [1.0, 2.0, 4.0, 8.0, 12.0, None],
    # Extreme
    [2.0, 5.0, 10.0, 20.0, 40.0, None],
]

# ---------------------------------------------------------------------------
# Velocity colour scheme
# ---------------------------------------------------------------------------
VELOCITY_COLOURS = [
    (216, 229, 240, 255),  # pale blue
    (103, 228, 237, 255),  # cyan
    ( 33,  87, 218, 255),  # blue
    (255, 255,   0, 255),  # yellow
    (255, 127,   0, 255),  # orange
    (227,  26,  28, 255),  # red
]

VELOCITY_BREAK_SETS = [
    [0.1, 0.2, 0.3, 0.4, 0.5, None],
    [0.25, 0.5, 0.75, 1.0, 1.5, None],
    [0.5, 1.0, 1.5, 2.0, 2.5, None],
    [1.0, 2.0, 4.0, 8.0, 12.0, None],
]

# ---------------------------------------------------------------------------
# SRC palette
# ---------------------------------------------------------------------------
SRC_PALETTE = [
    "#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4",
    "#42d4f4", "#f032e6", "#bfef45", "#fabed4", "#469990",
    "#dcbeff", "#9a6324", "#fffac8", "#800000", "#aaffc3",
    "#808000", "#ffd8b1", "#000075", "#a9a9a9", "#e6beff",
]

# ---------------------------------------------------------------------------
# Afflux colour schemes
# Each scheme is a list of (value, r, g, b, a, label) tuples, already in the
# exact order QGIS expects (ascending value, "inf" last where used).
# Two toggle-able schemes per Afflux type — clicking again cycles to the next.
# ---------------------------------------------------------------------------
AFFLUX_WD_SCHEMES = [
    # Scheme 1
    [
        (-99, 251, 1, 254, 204, "Was Wet Now Dry"),
        (99, 0, 0, 251, 204, "Was Dry Now Wet"),
    ],
    # Scheme 2
    [
        (-99, 0, 255, 0, 255, "Was Wet Now Dry"),
        (99, 132, 0, 168, 255, "Was Dry Now Wet"),
    ],
]

AFFLUX_SCHEMES = [
    # Scheme 1
    [
        (-0.01, 145, 218, 252, 255, "<= -10"),
        (0.01, 241, 241, 241, 221, "-10 - 10"),
        (0.02, 255, 255, 1, 255, "10 - 20"),
        (0.05, 254, 183, 158, 255, "20 - 50"),
        (0.10000000000000001, 254, 85, 0, 255, "50 - 100"),
        (0.20000000000000001, 253, 15, 0, 255, "100 - 200"),
        (float("inf"), 144, 0, 0, 255, "> 200"),
    ],
    # Scheme 2
    [
        (-0.10000000000000001, 0, 0, 127, 255, "Less than -100"),
        (-0.05, 0, 0, 255, 255, "-100 to 50"),
        (-0.035, 0, 127, 255, 255, "-50 to -35"),
        (-0.025, 0, 255, 255, 255, "-35 to -25"),
        (-0.01, 115, 255, 223, 255, "-25 to -10"),
        (0.01, 225, 225, 225, 255, "-10 to 10"),
        (0.025, 255, 255, 0, 255, "10 to 25"),
        (0.035, 255, 127, 127, 255, "25 to 35"),
        (0.05, 255, 127, 0, 255, "35 to 50"),
        (0.10000000000000001, 255, 0, 0, 255, "50 to 100"),
        (float("inf"), 128, 0, 0, 255, "More than 100"),
    ],
]

# ---------------------------------------------------------------------------
# Z0 colour scheme — breakpoints and RGBA
# Colours stay fixed; breakpoints cycle through magnitude tiers (smaller to
# larger) the same way Depth does, auto-picked from the raster's max value.
# ---------------------------------------------------------------------------
Z0_COLOURS = [
    (241, 235, 240, 255),
    (240, 180, 208, 255),
    (233,  81, 244, 255),
    ( 96,  43, 218, 255),
    (  0,  13, 255, 255),
    (  0,  23,  99, 255),
]

Z0_BREAK_SETS = [
    # Small
    [0.025, 0.05, 0.075, 0.1, 0.125, None],
    # Base (as supplied)
    [0.1, 0.2, 0.4, 0.6, 1.0, None],
    # Medium
    [0.25, 0.5, 0.75, 1.0, 1.25, None],
    # Large
    [0.5, 1.0, 2.0, 4.0, 6.0, None],
]

# ---------------------------------------------------------------------------
# H (water elevation) colour scheme
# Elevation varies wildly project to project, so instead of preset break
# sets we compute 6 equal-width classes between the raster's min and max
# each time, rounded to "nice" numbers. A classic 6-stop rainbow (low to
# high) is used since there's no universal "this value means X" convention
# for elevation the way there is for depth/velocity.
# ---------------------------------------------------------------------------
H_COLOURS_6 = [
    (0,   0, 255, 255),    # blue
    (0, 255, 255, 255),    # cyan
    (0, 255,   0, 255),    # green
    (255, 255, 0, 255),    # yellow
    (255, 128, 0, 255),    # orange
    (255,   0, 0, 255),    # red
]

H_COLOURS_10 = [
    (  0,   0, 255, 255),  # blue
    (  0, 128, 255, 255),  # light blue
    (  0, 255, 255, 255),  # cyan
    (  0, 230, 153, 255),  # turquoise
    (  0, 255,   0, 255),  # green
    (156, 255,   57, 255),  # lime
    (255, 255,   0, 255),  # yellow
    (255, 193,   0, 255),  # amber
    (255, 128,   0, 255),  # orange
    (255,   0,   0, 255),  # red
]

# ---------------------------------------------------------------------------
# ZAEM1 colour scheme
# Fixed hazard-category scheme (H1-H6). Only one option — no cycling.
# ---------------------------------------------------------------------------
ZAEM1_SCHEMES = [
    [
        (1, 33, 87, 181, 255, "H1 - Generally safe for people, vehicles and buildings."),
        (2, 103, 228, 237, 255, "H2 - Unsafe for small vehicles."),
        (3, 0, 165, 88, 255, "H3 - Unsafe for vehicles, children and the elderly."),
        (4, 175, 231, 99, 255, "H4 - Unsafe for people and vehicles."),
        (5, 255, 255, 1, 255, "H5 - Unsafe for people or vehicles. Buildings require special engineering design and construction."),
        (6, 221, 34, 22, 255, "H6 - Unsafe for vehicles and people. All building types considered vulnerable to failure."),
    ],
]


# ===========================================================================
# Transparency "hold" shortcut
# Hold Alt+T, then (while still holding) tap 0-9 for 0%-90% opacity, or F
# for 100%. Qt's QShortcut only supports modifiers + a single key, so a
# genuine "hold everything together" combo needs manual key-state
# tracking instead of a QKeySequence chord — see TransparencyKeyFilter
# below. Applies to every layer currently highlighted in the Layers
# panel, or the active layer if none are multi-selected.
# ===========================================================================
class TransparencyKeyFilter(QObject):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._t_held = False

    def eventFilter(self, obj, event):
        etype = event.type()

        if etype == QEvent.KeyPress:
            key = event.key()
            modifiers = event.modifiers()
            alt_down = bool(modifiers & Qt.AltModifier)

            if key == Qt.Key_T and alt_down:
                self._t_held = True
                return True  # swallow so it can't trigger a menu mnemonic

            if self._t_held and alt_down:
                opacity = None
                if Qt.Key_0 <= key <= Qt.Key_9:
                    opacity = (key - Qt.Key_0) / 10.0
                elif key == Qt.Key_F:
                    opacity = 1.0

                if opacity is not None:
                    set_layers_opacity(self.iface, opacity)
                    return True  # swallow so it doesn't type/do anything else

        elif etype == QEvent.KeyRelease:
            if event.key() == Qt.Key_T:
                self._t_held = False

        elif etype == QEvent.ApplicationDeactivate:
            # Window lost focus (e.g. alt-tabbed away) — clear stuck state
            self._t_held = False

        return False

# ===========================================================================
# Michael easter egg
# ===========================================================================
class MichaelKeyFilter(QObject):
    """
    Hold Alt+Shift, then (while still holding) type M, D in order to load
    michael.gpkg.

    Bare single-letter presses collide with QGIS's own tool shortcuts
    (M = measure, etc.), so requiring a modifier combo held throughout
    sidesteps that, matching the pattern already used by
    TransparencyKeyFilter (Alt+T) elsewhere in this file.
    """

    SEQUENCE = [
        Qt.Key_M,
        Qt.Key_D,
    ]

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.progress = 0

    def _modifiers_held(self, modifiers):
        return bool(modifiers & Qt.AltModifier) and bool(modifiers & Qt.ShiftModifier)

    def eventFilter(self, obj, event):
        etype = event.type()

        if etype == QEvent.KeyPress:

            if event.isAutoRepeat():
                return False

            modifiers = event.modifiers()

            if not self._modifiers_held(modifiers):
                self.progress = 0
                return False

            key = event.key()
            expected = self.SEQUENCE[self.progress]

            if key == expected:
                self.progress += 1

                if self.progress == len(self.SEQUENCE):
                    self.progress = 0
                    self.load_michael()
                    return True

                return True  # swallow so it can't trigger anything else mid-sequence

            elif key == self.SEQUENCE[0]:
                self.progress = 1
                return True

            else:
                self.progress = 0

        elif etype == QEvent.KeyRelease:
            # Losing either modifier mid-sequence resets progress.
            if event.key() in (Qt.Key_Alt, Qt.Key_Shift):
                self.progress = 0

        elif etype == QEvent.ApplicationDeactivate:
            self.progress = 0

        return False

    def load_michael(self):

        try:
            QMessageBox.information(
                self.iface.mainWindow(),
                "Michael",
                "Michael will now review your workspace.",
                QMessageBox.Ok
            )

            plugin_folder = os.path.dirname(__file__)
            gpkg_path = os.path.join(plugin_folder, "michael.gpkg")

            layer = QgsVectorLayer(
                gpkg_path,
                "Michael",
                "ogr"
            )

            if not layer.isValid():
                raise ValueError(
                    f"Unable to load:\n{gpkg_path}"
                )

            QgsProject.instance().addMapLayer(layer)

            self._style_michael_black(layer)

            recenter_warning = self._move_layer_to_canvas_center(layer)

            if recenter_warning:
                self.iface.messageBar().pushWarning(
                    "Michael",
                    f"Michael has arrived, but couldn't be recentred: {recenter_warning}"
                )
            else:
                self.iface.messageBar().pushSuccess(
                    "Michael",
                    "Michael has arrived."
                )

        except Exception as e:

            self.iface.messageBar().pushWarning(
                "Michael",
                str(e)
            )

    def _style_michael_black(self, layer):
        """Force Michael's outline/line colour to black regardless of geometry type."""
        try:
            renderer = layer.renderer()
            if renderer is None:
                return

            symbol = renderer.symbol()
            if symbol is None:
                return

            # setColor sets fill for polygons/points, stroke for lines.
            # Explicitly set stroke colour too so polygon/point outlines
            # turn black even though setColor alone only changes the fill.
            symbol.setColor(QColor(0, 0, 0))

            for layer_sym in symbol.symbolLayers():
                if hasattr(layer_sym, "setStrokeColor"):
                    layer_sym.setStrokeColor(QColor(0, 0, 0))

            layer.triggerRepaint()

            if self.iface:
                self.iface.layerTreeView().refreshLayerSymbology(layer.id())

        except Exception:
            pass  # styling is cosmetic — never let it block Michael from loading

    def _move_layer_to_canvas_center(self, layer):
        """
        Translates every feature in the layer so the layer's extent is
        recentred on the current map canvas view. Returns None on success,
        or a short warning string if recentring couldn't be done — in
        which case Michael still loads, just at his original position,
        rather than the whole load being aborted.
        """
        try:
            canvas = self.iface.mapCanvas()
            canvas_extent = canvas.extent()

            if canvas_extent.isEmpty():
                return "canvas extent is empty"

            canvas_crs = canvas.mapSettings().destinationCrs()
            layer_crs = layer.crs()

            if not canvas_crs.isValid() or not layer_crs.isValid():
                return "layer or canvas CRS is not defined"

            target_extent = canvas_extent

            if canvas_crs != layer_crs:
                transform = QgsCoordinateTransform(
                    canvas_crs,
                    layer_crs,
                    QgsProject.instance()
                )
                target_extent = transform.transformBoundingBox(canvas_extent)

            if target_extent.isEmpty():
                return "canvas extent could not be converted to the layer's CRS"

            target_center = target_extent.center()

            layer_extent = layer.extent()

            if layer_extent.isEmpty():
                return "Michael's layer has no features to move"

            current_center = layer_extent.center()
            dx = target_center.x() - current_center.x()
            dy = target_center.y() - current_center.y()

            if dx == 0 and dy == 0:
                return None

            layer.startEditing()

            for feature in layer.getFeatures():
                geom = feature.geometry()
                geom.translate(dx, dy)
                layer.changeGeometry(feature.id(), geom)

            layer.commitChanges()
            layer.triggerRepaint()

            return None

        except Exception as e:
            return str(e)

def get_selected_or_active_layers(iface):
    """
    Returns the layers currently highlighted in the Layers panel, or a
    single-item list with the active layer if nothing is multi-selected.
    """
    layers = iface.layerTreeView().selectedLayers()

    if not layers:
        active = iface.activeLayer()
        if active:
            layers = [active]

    return layers

def set_layers_opacity(iface, opacity):
    layers = get_selected_or_active_layers(iface)
    if not layers:
        return

    styled_names = []

    for layer in layers:
        try:
            layer.setOpacity(opacity)
            layer.triggerRepaint()
            iface.layerTreeView().refreshLayerSymbology(layer.id())
            styled_names.append(layer.name())
        except Exception:
            continue

    if not styled_names:
        return

    label = styled_names[0] if len(styled_names) == 1 else f"{len(styled_names)} layers"
    iface.mainWindow().statusBar().showMessage(
        f"{label} opacity: {round(opacity * 100)}%", 1500
    )



# ===========================================================================
# Icon
# ===========================================================================
def make_icon(size=32):
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.transparent)

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)

    font = QFont("Arial", int(size * 0.30), QFont.Bold)
    painter.setFont(font)

    letters = [
        ("H", "#e6194b"),  # red
        ("U", "#3cb44b"),  # green
        ("G", "#4363d8"),  # blue
        ("O", "#f58231"),  # orange
    ]

    letter_w = size // 4

    for i, (letter, colour) in enumerate(letters):
        painter.setPen(QColor(colour))
        painter.drawText(
            i * letter_w,
            0,
            letter_w,
            size,
            Qt.AlignCenter,
            letter
        )

    painter.end()
    return QIcon(pixmap)


# ===========================================================================
# Filename analysis
# ===========================================================================
def get_raster_type(layer):
    """
    Returns ('depth'|'velocity'|'src'|'afflux'|'afflux_wd'|'z0'|'zaem1'|'h'|'dem_m'|'dem'|None, message)
    based on filename suffix. Checks extension validity first.
    """
    src_path = layer.source()
    ext = os.path.splitext(src_path)[1].lower()

    if ext not in SUPPORTED_EXTENSIONS:
        return None, (
            f"Unsupported file type: '{ext}'\n\n"
            f"Hugo's Magic Colours supports: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )

    name_lower = src_path.lower()

    # Strip extension for suffix checking
    stem_lower = name_lower[: -len(ext)] if ext else name_lower

    # Afflux check comes first — filenames are "Afflux_x" or "Afflux_x_wd"
    # where x is an arbitrary afflux-type token we don't care about.
    if "afflux" in stem_lower:
        if stem_lower.endswith("_wd"):
            return "afflux_wd", None
        return "afflux", None

    for s in ZAEM1_SUFFIXES:
        if stem_lower.endswith(s.lower()):
            return "zaem1", None

    for s in Z0_SUFFIXES:
        if stem_lower.endswith(s.lower()):
            return "z0", None

    for s in H_SUFFIXES:
        if stem_lower.endswith(s.lower()):
            return "h", None

    for s in SRC_SUFFIXES:
        if stem_lower.endswith(s.lower()):
            return "src", None

    for s in VELOCITY_SUFFIXES:
        if stem_lower.endswith(s.lower()):
            return "velocity", None

    for s in DEPTH_SUFFIXES:
        if stem_lower.endswith(s.lower()):
            return "depth", None

    # DEM_M is a special-material DEM variant. It must be checked before
    # the generic "dem" substring check below, since "_dem_m" also
    # contains "dem" and would otherwise be swallowed by the generic
    # DEM branch — DEM_M is deliberately excluded from ordinary DEM
    # styling and routed to its own materials-based styler instead.
    for s in DEM_M_SUFFIXES:
        if stem_lower.endswith(s.lower()):
            return "dem_m", None

    if "dem" in stem_lower:
        return "dem", None

    return None, (
        f"Filename suffix not recognised:\n{os.path.basename(src_path)}\n\n"
        "Supported suffixes:\n"
        "  Depth:  _d_Max, _Max_d\n"
        "  Velocity:  _V_Max, _Max_V\n"
        "  SRC:    _Src\n"
        "  Afflux: contains 'afflux' (optionally ending in '_wd')\n"
        "  Z0:     _Z0, _Z0_Max\n"
        "  ZAEM1:  _ZAEM1, _ZAEM1_Max\n"
        "  H:      _H, _H_Max\n"
        "  DEM_M:  _DEM_M\n"
        "  DEM: contains 'dem'"
    )


# ===========================================================================
# Renderer application helper
# setRenderer() rebuilds the layer's legend nodes, which resets the layer's
# expanded/collapsed state in the Layers panel. We capture and restore it
# so restyling a layer doesn't visually "close up" its legend entry.
#
# FIX (2026-08): QgsSingleBandPseudoColorRenderer keeps classificationMin/
# classificationMax as separate metadata from the shader's actual colour
# ramp items — these two values are what the Layer Properties > Symbology
# widget uses to populate its editable classification table when the
# dialog is opened. We were never setting them, so they defaulted to
# NaN/NaN. With NaN min/max, the widget couldn't match its table against
# our real (discrete) shader items, so it silently fell back to
# regenerating a bogus continuous classification from the raster's live
# band statistics instead — visible in Properties, but not affecting the
# canvas or the Layers-panel legend, which read the shader directly.
# Setting classificationMin/Max here from the actual finite breakpoints
# fixes that without touching any rendering behaviour.
# ===========================================================================
def apply_renderer(layer, iface, renderer):
    node = None
    was_expanded = None

    if iface:
        node = QgsProject.instance().layerTreeRoot().findLayer(layer.id())
        if node is not None:
            was_expanded = node.isExpanded()

    if isinstance(renderer, QgsSingleBandPseudoColorRenderer):
        try:
            shader_fn = renderer.shader().rasterShaderFunction()
            items = shader_fn.colorRampItemList()
            finite_values = [
                item.value for item in items
                if item.value not in (float("inf"), float("-inf"))
            ]
            if finite_values:
                renderer.setClassificationMin(min(finite_values))
                renderer.setClassificationMax(max(finite_values))
        except Exception:
            pass

    layer.setRenderer(renderer)
    layer.triggerRepaint()

    if iface:
        iface.layerTreeView().refreshLayerSymbology(layer.id())

    if node is not None and was_expanded is not None:
        node.setExpanded(was_expanded)


# ===========================================================================
# Depth styling
# ===========================================================================
def choose_depth_breaks(max_val):
    """Pick the most appropriate breakpoint set for this raster's max depth."""
    for idx, breaks in enumerate(DEPTH_BREAK_SETS):
        finite = [b for b in breaks if b is not None]
        if max_val <= finite[-1] * 1.5:
            return idx, breaks

    return len(DEPTH_BREAK_SETS) - 1, DEPTH_BREAK_SETS[-1]

def choose_velocity_breaks(max_val):
    for breaks in VELOCITY_BREAK_SETS:
        finite = [b for b in breaks if b is not None]
        if max_val <= finite[-1] * 1.5:
            return breaks

    return VELOCITY_BREAK_SETS[-1]

def get_current_depth_break_set_index(layer):
    """
    Returns the DEPTH_BREAK_SETS index currently applied to the layer.
    Returns None if the renderer doesn't match one of our schemes.
    """
    renderer = layer.renderer()

    if not isinstance(renderer, QgsSingleBandPseudoColorRenderer):
        return None

    try:
        shader = renderer.shader()
        shader_fn = shader.rasterShaderFunction()
        items = shader_fn.colorRampItemList()
    except Exception:
        return None

    current_breaks = []

    for item in items[:-1]:  # ignore final inf class
        try:
            current_breaks.append(float(item.value))
        except Exception:
            return None

    for idx, breaks in enumerate(DEPTH_BREAK_SETS):
        finite = [b for b in breaks if b is not None]

        if len(finite) != len(current_breaks):
            continue

        if all(abs(a - b) < 1e-6 for a, b in zip(finite, current_breaks)):
            return idx

    return None

def get_current_velocity_break_set_index(layer):
    renderer = layer.renderer()

    if not isinstance(renderer, QgsSingleBandPseudoColorRenderer):
        return None

    try:
        shader = renderer.shader()
        shader_fn = shader.rasterShaderFunction()
        items = shader_fn.colorRampItemList()
    except Exception:
        return None

    current_breaks = []

    for item in items[:-1]:  # ignore final inf class
        try:
            current_breaks.append(float(item.value))
        except Exception:
            return None

    for idx, breaks in enumerate(VELOCITY_BREAK_SETS):
        finite = [b for b in breaks if b is not None]

        if len(finite) != len(current_breaks):
            continue

        if all(abs(a - b) < 1e-6 for a, b in zip(finite, current_breaks)):
            return idx

    return None
 
def choose_z0_breaks(max_val):
    """Pick the most appropriate breakpoint tier for this raster's max value."""
    for idx, breaks in enumerate(Z0_BREAK_SETS):
        finite = [b for b in breaks if b is not None]
        if max_val <= finite[-1] * 1.5:
            return idx, breaks

    return len(Z0_BREAK_SETS) - 1, Z0_BREAK_SETS[-1]

def get_current_z0_break_set_index(layer):
    """
    Returns the Z0_BREAK_SETS index currently applied to the layer.
    Returns None if the renderer doesn't match one of our schemes.
    """
    renderer = layer.renderer()

    if not isinstance(renderer, QgsSingleBandPseudoColorRenderer):
        return None

    try:
        shader = renderer.shader()
        shader_fn = shader.rasterShaderFunction()
        items = shader_fn.colorRampItemList()
    except Exception:
        return None

    current_breaks = []

    for item in items[:-1]:  # ignore final inf class
        try:
            current_breaks.append(float(item.value))
        except Exception:
            return None

    for idx, breaks in enumerate(Z0_BREAK_SETS):
        finite = [b for b in breaks if b is not None]

        if len(finite) != len(current_breaks):
            continue

        if all(abs(a - b) < 1e-6 for a, b in zip(finite, current_breaks)):
            return idx

    return None

def style_depth(layer, iface):
    provider = layer.dataProvider()
    stats = provider.bandStatistics(1, QgsRasterBandStats.All)
    max_val = stats.maximumValue

    auto_idx, auto_breaks = choose_depth_breaks(max_val)

    current_idx = get_current_depth_break_set_index(layer)

    if current_idx is None:
        breaks_idx = auto_idx
    else:
        breaks_idx = (current_idx + 1) % len(DEPTH_BREAK_SETS)

    breaks = DEPTH_BREAK_SETS[breaks_idx]

    items = []
    prev = None

    for brk, rgba in zip(breaks, DEPTH_COLOURS):
        r, g, b, a = rgba
        color = QColor(r, g, b, a)

        if brk is None:
            label = f"> {prev}"
            value = float("inf")
        else:
            if prev is None:
                label = f"<= {brk}"
            else:
                label = f"{prev} - {brk}"
            value = brk

        items.append(
            QgsColorRampShader.ColorRampItem(
                value,
                color,
                label
            )
        )

        if brk is not None:
            prev = brk

    shader_fn = QgsColorRampShader()
    shader_fn.setColorRampType(QgsColorRampShader.Discrete)
    shader_fn.setColorRampItemList(items)

    raster_shader = QgsRasterShader()
    raster_shader.setRasterShaderFunction(shader_fn)

    renderer = QgsSingleBandPseudoColorRenderer(
        provider,
        1,
        raster_shader
    )

    apply_renderer(layer, iface, renderer)

    return (
        f"Depth styled (max = {max_val:.2f} m) "
        f"[Scheme {breaks_idx + 1}/{len(DEPTH_BREAK_SETS)}]"
    )

def style_velocity(layer, iface):
    provider = layer.dataProvider()
    stats = provider.bandStatistics(1, QgsRasterBandStats.All)
    max_val = stats.maximumValue

    auto_idx = None
    for idx, breaks in enumerate(VELOCITY_BREAK_SETS):
        finite = [b for b in breaks if b is not None]
        if max_val <= finite[-1] * 1.5:
            auto_idx = idx
            break

    if auto_idx is None:
        auto_idx = len(VELOCITY_BREAK_SETS) - 1

    current_idx = get_current_velocity_break_set_index(layer)

    if current_idx is None:
        breaks_idx = auto_idx
    else:
        breaks_idx = (current_idx + 1) % len(VELOCITY_BREAK_SETS)

    breaks = VELOCITY_BREAK_SETS[breaks_idx]

    items = []
    prev = None

    for brk, rgba in zip(breaks, VELOCITY_COLOURS):
        r, g, b, a = rgba
        color = QColor(r, g, b, a)

        if brk is None:
            label = f"> {prev:.2f}"
            value = float("inf")
        else:
            if prev is None:
                label = f"<= {brk:.2f}"
            else:
                label = f"{prev:.2f} - {brk:.2f}"
            value = brk

        items.append(
            QgsColorRampShader.ColorRampItem(
                value,
                color,
                label
            )
        )

        if brk is not None:
            prev = brk

    shader_fn = QgsColorRampShader()
    shader_fn.setColorRampType(QgsColorRampShader.Discrete)
    shader_fn.setColorRampItemList(items)

    raster_shader = QgsRasterShader()
    raster_shader.setRasterShaderFunction(shader_fn)

    renderer = QgsSingleBandPseudoColorRenderer(
        provider,
        1,
        raster_shader
    )

    apply_renderer(layer, iface, renderer)

    return (
        f"Velocity styled (max = {max_val:.2f} m/s) "
        f"[Scheme {breaks_idx + 1}/{len(VELOCITY_BREAK_SETS)}]"
    )


def style_z0(layer, iface):
    provider = layer.dataProvider()
    stats = provider.bandStatistics(1, QgsRasterBandStats.All)
    max_val = stats.maximumValue

    auto_idx, auto_breaks = choose_z0_breaks(max_val)

    current_idx = get_current_z0_break_set_index(layer)

    if current_idx is None:
        breaks_idx = auto_idx
    else:
        breaks_idx = (current_idx + 1) % len(Z0_BREAK_SETS)

    breaks = Z0_BREAK_SETS[breaks_idx]

    items = []
    prev = None

    for brk, rgba in zip(breaks, Z0_COLOURS):
        r, g, b, a = rgba
        color = QColor(r, g, b, a)

        if brk is None:
            label = f"> {prev}"
            value = float("inf")
        else:
            if prev is None:
                label = f"<= {brk}"
            else:
                label = f"{prev} - {brk}"
            value = brk

        items.append(
            QgsColorRampShader.ColorRampItem(
                value,
                color,
                label
            )
        )

        if brk is not None:
            prev = brk

    shader_fn = QgsColorRampShader()
    shader_fn.setColorRampType(QgsColorRampShader.Discrete)
    shader_fn.setColorRampItemList(items)

    raster_shader = QgsRasterShader()
    raster_shader.setRasterShaderFunction(shader_fn)

    renderer = QgsSingleBandPseudoColorRenderer(
        provider,
        1,
        raster_shader
    )

    apply_renderer(layer, iface, renderer)

    return (
        f"Z0 styled (max = {max_val:.2f}) "
        f"[Scheme {breaks_idx + 1}/{len(Z0_BREAK_SETS)}]"
    )


# ===========================================================================
# DEM styling
# ===========================================================================
DEM_TOGGLE_PROPERTY = "hugosmagiccolours/dem_mode"
DEM_RAMP_PROPERTY = "hugosmagiccolours/dem_ramp"

# Rapid triple-click detection for DEM colour-ramp switching.
# Three clicks within this period switches between Topo and Rainbow.
DEM_TRIPLE_CLICK_INTERVAL = 600  # milliseconds

# ---------------------------------------------------------------------------
# Bundled "Topo" colour ramp
#
# The cpt-city "Extras" ramp pack (which includes Topo) is an optional
# download — plugin users who never installed it get QgsStyle.defaultStyle()
# .colorRamp("Topo") returning None, which previously crashed style_dem().
#
# To make Topo work for everyone regardless of what's installed locally, we
# carry the actual ramp data as an exported "QGIS Generated Color Map" text
# block (the same format QGIS's own colour-ramp export produces) and parse
# it at runtime into a QgsGradientColorRamp. The literal elevation values
# in the export are irrelevant here — we only care about each stop's
# relative position, so every value is renormalised to a 0-1 fraction
# based on the min/max value present in the data itself. That means this
# ramp stretches correctly across whatever elevation range a given DEM
# actually has.
# ---------------------------------------------------------------------------
TOPO_RAMP_DATA = """# QGIS Generated Color Map Export File
INTERPOLATION:INTERPOLATED
73.9803009033203125,174,239,213,255,74
74.58910134735107533,175,240,211,255,74.6
75.18881521759033149,176,242,208,255,75.2
75.79761566162109432,176,242,202,255,75.8
76.40641610565185715,177,242,196,255,76.4
77.0061299758911133,176,243,190,255,77
77.61493041992187614,176,244,186,255,77.6
78.22373086395263897,178,246,181,255,78.2
78.82344473419189512,181,246,178,255,78.8
79.43224517822265796,186,247,178,255,79.4
80.04104562225342079,192,247,178,255,80
80.64075949249267694,198,248,178,255,80.6
81.24955993652343977,204,249,178,255,81.2
81.85836038055420261,210,250,177,255,81.9
82.45807425079345876,217,250,178,255,82.5
83.06687469482422159,224,251,178,255,83.1
83.67567513885498443,231,252,178,255,83.7
84.27538900909424058,238,252,179,255,84.3
84.88418945312500341,245,252,179,255,84.9
85.49298989715576624,250,252,178,255,85.5
86.0927037673950224,248,249,172,255,86.1
86.70150421142578523,238,244,162,255,86.7
87.31030465545654806,226,240,151,255,87.3
87.91001852569580421,213,235,140,255,87.9
88.51881896972656705,198,228,128,255,88.5
89.12761941375731567,184,222,118,255,89.1
89.72733328399658603,170,216,108,255,89.7
90.33613372802733466,154,211,98,255,90.3
90.9449341720581117,140,205,89,255,90.9
91.54464804229736785,125,199,82,255,91.5
92.15344848632813068,110,194,74,255,92.2
92.76224893035887931,94,188,66,255,92.8
93.36196280059814967,77,182,57,255,93.4
93.97076324462889829,62,176,50,255,94
94.57956368865967534,49,171,44,255,94.6
95.17927755889893149,39,165,42,255,95.2
95.78807800292969432,30,160,43,255,95.8
96.39687844696044294,24,154,46,255,96.4
96.99659231719971331,18,148,49,255,97
97.60539276123046193,14,142,52,255,97.6
98.21419320526122476,9,137,56,255,98.2
98.81390707550048091,7,132,60,255,98.8
99.42270751953125796,12,130,63,255,99.4
100.03150796356200658,24,130,63,255,100
100.63122183380127694,40,132,61,255,101
101.24002227783202557,52,136,60,255,101
101.8488227218627884,64,140,59,255,102
102.44853659210204455,76,142,59,255,102
103.05733703613282159,87,146,56,255,103
103.66613748016357022,99,148,54,255,104
104.26585135040282637,110,150,52,255,104
104.8746517944335892,120,154,50,255,105
105.48345223846435204,128,156,48,255,105
106.08316610870360819,137,160,46,255,106
106.69196655273437102,147,162,43,255,107
107.30076699676513385,156,164,41,255,107
107.90048086700440422,166,166,39,255,108
108.50928131103515284,176,170,36,255,109
109.11808175506591567,187,173,34,255,109
109.71779562530517182,197,176,30,255,110
110.32659606933594887,207,177,28,255,110
110.93539651336669749,218,179,24,255,111
111.53511038360595364,228,180,20,255,112
112.14391082763671648,238,182,14,255,112
112.75271127166747931,246,182,8,255,113
113.35242514190673546,248,176,4,255,113
113.96122558593749829,244,166,2,255,114
114.57002602996826113,238,155,2,255,115
115.16973990020751728,232,144,2,255,115
115.77854034423828011,226,132,2,255,116
116.38734078826904295,220,122,2,255,116
116.9870546585082991,216,111,2,255,117
117.59585510253906193,211,102,2,255,118
118.20465554656982476,206,92,2,255,118
118.80436941680908092,200,84,2,255,119
119.41316986083984375,192,74,2,255,119
120.02197030487060658,186,66,2,255,120
120.62168417510986274,180,58,2,255,121
121.23048461914062557,174,49,2,255,121
121.8392850631713884,169,42,2,255,122
122.43899893341064455,163,36,2,255,122
123.04779937744140739,157,30,2,255,123
123.65659982147215601,151,23,2,255,124
124.25631369171142637,146,18,1,255,124
124.86511413574218921,141,14,1,255,125
125.47391457977295204,135,8,0,255,125
126.07362845001220819,130,5,0,255,126
126.68242889404297102,125,4,0,255,127
127.29122933807373386,122,8,2,255,127
127.89094320831299001,119,13,2,255,128
128.49974365234373863,118,16,2,255,128
129.10854409637451568,117,18,4,255,129
129.70825796661375762,117,20,4,255,130
130.31705841064453466,117,21,4,255,130
130.9258588546753117,116,22,4,255,131
131.52557272491455365,116,24,5,255,132
132.13437316894533069,114,26,6,255,132
132.74317361297607931,114,29,6,255,133
133.34288748321532125,112,31,7,255,133
133.9516879272460983,111,33,8,255,134
134.56048837127684692,110,35,8,255,135
135.16020224151611728,110,36,8,255,135
135.76900268554686591,109,38,9,255,136
136.37780312957764295,108,40,10,255,136
136.97751699981688489,108,40,10,255,137
137.58631744384766193,108,42,10,255,138
138.19511788787841056,107,44,11,255,138
138.79483175811768092,106,44,12,255,139
139.40363220214842954,106,46,12,255,139
140.01243264617920659,107,48,14,255,140
140.61214651641844853,110,52,18,255,141
141.22094696044922557,113,57,23,255,141
141.82974740447997419,116,62,28,255,142
142.42946127471924456,118,66,32,255,142
143.03826171874999318,121,70,37,255,143
143.64706216278077022,125,74,43,255,144
144.24677603302001216,128,79,50,255,144
144.85557647705078921,131,85,56,255,145
145.46437692108153783,135,90,63,255,145
146.06409079132080819,138,96,69,255,146
146.67289123535158524,140,101,76,255,147
147.28169167938233386,144,106,84,255,147
147.88140554962160422,147,111,90,255,148
148.49020599365235284,150,116,96,255,148
149.09900643768310147,152,122,104,255,149
149.69872030792237183,156,129,112,255,150
150.30752075195312045,158,135,120,255,150
150.91632119598386907,160,141,130,255,151
151.51603506622313944,163,147,139,255,152
152.12483551025388806,166,154,147,255,152
152.7336359542846651,167,160,156,255,153
153.33334982452390705,170,167,164,255,153
153.94215026855468409,172,172,171,255,154
154.55095071258546113,174,174,174,255,155
155.15066458282470307,178,178,178,255,155
155.75946502685548012,181,181,181,255,156
156.36826547088622874,184,184,184,255,156
156.9679793411254991,188,188,188,255,157
157.57677978515624773,192,192,192,255,158
158.18558022918699635,196,196,196,255,158
158.78529409942626671,200,200,200,255,159
159.39409454345701533,204,204,204,255,159
160.00289498748779238,208,206,208,255,160
160.60260885772703432,212,210,212,255,161
161.21140930175781136,216,214,216,255,161
161.82020974578858841,218,216,218,255,162
162.41992361602783035,221,219,221,255,162
163.02872406005860739,225,223,225,255,163
163.63752450408935601,229,227,229,255,164
164.23723837432862638,233,231,233,255,164
164.846038818359375,235,233,235,255,165
"""

_topo_ramp_cache = None


def _parse_topo_ramp_data():
    """
    Parses TOPO_RAMP_DATA (a standard QGIS colour-map export) into a list
    of (fraction, QColor) tuples, where fraction is each row's position
    renormalised to 0-1 based on the min/max value in the data. The
    literal elevation values in the export are otherwise unused.
    """
    rows = []

    for line in TOPO_RAMP_DATA.strip().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("INTERPOLATION"):
            continue

        parts = line.split(",")
        if len(parts) < 5:
            continue

        try:
            value = float(parts[0])
            r, g, b, a = (int(parts[1]), int(parts[2]), int(parts[3]), int(parts[4]))
        except ValueError:
            continue

        rows.append((value, QColor(r, g, b, a)))

    if len(rows) < 2:
        return None

    min_val = rows[0][0]
    max_val = rows[-1][0]
    span = max_val - min_val

    if span <= 0:
        return None

    return [((v - min_val) / span, color) for v, color in rows]


def _load_bundled_topo_ramp():
    """
    Builds (and caches) a QgsGradientColorRamp for "Topo" from the bundled
    ramp data, so DEM styling works even for users who never installed the
    optional cpt-city 'Extras' ramp pack.
    """
    global _topo_ramp_cache

    if _topo_ramp_cache is not None:
        return _topo_ramp_cache

    parsed = _parse_topo_ramp_data()
    if not parsed:
        return None

    color1 = parsed[0][1]
    color2 = parsed[-1][1]

    # Interior stops only — first/last positions are color1/color2.
    stops = [
        QgsGradientStop(fraction, color)
        for fraction, color in parsed[1:-1]
    ]

    _topo_ramp_cache = QgsGradientColorRamp(color1, color2, False, stops)
    return _topo_ramp_cache


def style_dem(layer, iface, rainbow_toggle=False):

    mode = int(layer.customProperty(DEM_TOGGLE_PROPERTY, 0))
    current_ramp = layer.customProperty(
        DEM_RAMP_PROPERTY,
        "topo"
    )

    # ===============================================================
    # 1. HANDLE RAPID TRIPLE-CLICK COLOUR-RAMP TOGGLE
    # ===============================================================

    if rainbow_toggle:
        current_ramp = (
            "RdYlBu"
            if current_ramp == "topo"
            else "topo"
        )

        layer.setCustomProperty(
            DEM_RAMP_PROPERTY,
            current_ramp
        )

        # Restart the DEM mode cycle when changing colour ramps.
        mode = 0

    # ===============================================================
    # 2. GET THE SELECTED QGIS COLOUR RAMP
    #
    # "Topo" comes from the cpt-city Extras pack, which not every user
    # has installed — style.colorRamp("Topo") returns None in that case.
    # Fall back to our bundled copy so it always works.
    # ===============================================================

    style = QgsStyle.defaultStyle()

    if current_ramp == "RdYlBu":
        ramp = style.colorRamp("RdYlBu")
        ramp_name = "RdYlBu"
    else:
        ramp = style.colorRamp("Topo") or _load_bundled_topo_ramp()
        ramp_name = "Topo"

    if ramp is None:
        raise ValueError(
            f"Could not find the QGIS '{ramp_name}' colour ramp."
        )

    # ===============================================================
    # 3. CREATE PSEUDOCOLOR RENDERER
    # ===============================================================

    provider = layer.dataProvider()

    renderer = QgsSingleBandPseudoColorRenderer(
        provider,
        1
    )

    # ===============================================================
    # 4. SET MIN/MAX STATISTICS EXTENT
    #
    # mode 0 = Whole raster
    # mode 1 = Updated canvas
    # mode 2 = Current canvas
    # ===============================================================

    minmax = QgsRasterMinMaxOrigin()

    minmax.setLimits(
        RASTER_LIMIT_MINMAX
    )

    if mode == 0:

        minmax.setExtent(
            RASTER_EXTENT_WHOLE
        )

        extent_desc = "whole raster"

    elif mode == 1:

        minmax.setExtent(
            RASTER_EXTENT_UPDATED
        )

        extent_desc = "updated canvas"

    else:

        minmax.setExtent(
            RASTER_EXTENT_CURRENT
        )

        extent_desc = "current canvas"

    renderer.setMinMaxOrigin(minmax)

    # ===============================================================
    # 5. GET INITIAL MIN/MAX
    # ===============================================================

    if mode == 0:

        stats = provider.bandStatistics(
            1,
            QgsRasterBandStats.All
        )

        min_val = stats.minimumValue
        max_val = stats.maximumValue

    elif mode == 2:

        canvas = iface.mapCanvas()

        extent = canvas.extent()

        canvas_crs = canvas.mapSettings().destinationCrs()

        if canvas_crs != layer.crs():

            transform = QgsCoordinateTransform(
                canvas_crs,
                layer.crs(),
                QgsProject.instance()
            )

            extent = transform.transformBoundingBox(extent)

        extent = extent.intersect(layer.extent())

        if extent.isEmpty():
            raise ValueError(
                "Current canvas does not overlap the DEM."
            )

        stats = provider.bandStatistics(
            1,
            QgsRasterBandStats.All,
            extent,
            0
        )

        min_val = stats.minimumValue
        max_val = stats.maximumValue

    else:

        # Updated canvas needs an initial range so the renderer
        # can be created. The renderer will subsequently update it.
        stats = provider.bandStatistics(
            1,
            QgsRasterBandStats.All
        )

        min_val = stats.minimumValue
        max_val = stats.maximumValue

    # ===============================================================
    # 6. SET CLASSIFICATION RANGE
    # ===============================================================

    renderer.setClassificationMin(min_val)
    renderer.setClassificationMax(max_val)

    # ===============================================================
    # 7. CREATE CONTINUOUS COLOUR RAMP
    #
    # Same QGIS behaviour as the existing DEM styling.
    # Only the selected colour ramp changes.
    # ===============================================================

    renderer.createShader(
        ramp,
        QgsColorRampShader.Interpolated,
        QgsColorRampShader.Continuous,
        5,
        False
    )

    # ===============================================================
    # 8. APPLY
    # ===============================================================

    apply_renderer(
        layer,
        iface,
        renderer
    )

    # ===============================================================
    # 9. NEXT DEM MODE
    # ===============================================================

    layer.setCustomProperty(
        DEM_TOGGLE_PROPERTY,
        (mode + 1) % 3
    )

    return (
        f"DEM styled — {ramp_name} — {extent_desc}"
    )


# ===========================================================================
# DEM_M (special-material DEM) styling
#
# DEM_M rasters carry a unique integer material ID per cell rather than an
# elevation value. To style one we have to work backwards from the raster
# file to the TUFLOW run that produced it:
#
#   1. <...check\EVENT\...DEM_M.tif>  — the selected raster
#   2. <...log\EVENT\...tlf>          — matching .tlf log, found by
#                                        swapping the "check" folder for
#                                        "log" and dropping the _DEM_M
#                                        suffix from the filename
#   3. inside the .tlf, a line naming the materials file that was used
#      for the run — this can be a ".tmf" OR a ".csv"; TUFLOW logs both
#      the same way. A single .tlf can reference several other .tmf/.csv
#      files (e.g. a "_messages.csv" log, or a .tef event file) reusing
#      the same File Unit number, so the materials file is identified
#      specifically as the one QGIS/TUFLOW immediately follows with
#      "N...Processing: <id>, <mannings>, ..." rows before closing that
#      File Unit — that Processing block only appears for the materials
#      file, so it's what disambiguates it from the other candidates.
#   4. the materials file itself, which maps each material ID to a
#      Manning's n value and (usually) a descriptive comment. Rows can
#      be comma- or tab-separated, may have a header row ("Material ID,
#      Manning's n, ...") that isn't real data, and comments may appear
#      either as a trailing "! comment" or as their own "!comment" field.
#
# The raster's unique values are then styled with one colour per material
# ID, labelled "ID | Manning's n | Comment".
# ===========================================================================

# Matches a "Trying to open (I) file <path>...OK.  File Unit: <n>" line
# together with everything up to the matching "...Closed File Unit: <n>"
# for that same unit — i.e. everything TUFLOW logged while that file was
# open. Used to inspect what happened between open/close, not just the
# open line itself, since the open line alone isn't enough to tell a
# materials file apart from other files that share the same File Unit
# number later in the log.
MATERIALS_OPEN_RE = re.compile(
    r"Trying to open \(I\) file\s+(?P<path>.+?)\s*\.\.\.\s*OK\.\s*File Unit:\s*(?P<unit>\d+)"
    r"(?P<body>.*?)"
    r"\.\.\.Closed File Unit:\s*(?P=unit)",
    re.IGNORECASE | re.DOTALL
)

# Identifies the materials-processing block specifically: TUFLOW echoes
# each material row back as "N...Processing: <id>, <mannings>, ...".
# Only a materials file (.tmf or .csv) produces this while it's open.
MATERIALS_PROCESSING_RE = re.compile(r"Processing:\s*\d+\s*[,\t]")

MATERIALS_EXTENSIONS = (".tmf", ".csv")


def find_dem_m_tlf(dem_m_path):
    """
    Given the path to a *_DEM_M raster, derives the path of the matching
    .tlf log file: same event name, but living in a neighbouring "log"
    folder instead of "check", with the "_DEM_M" suffix dropped.
    """
    folder = os.path.dirname(dem_m_path)
    basename = os.path.basename(dem_m_path)
    stem, _ext = os.path.splitext(basename)

    stem_lower = stem.lower()
    if stem_lower.endswith("_dem_m"):
        event_stem = stem[: -len("_dem_m")]
    else:
        event_stem = stem

    norm_folder = os.path.normpath(folder)
    parts = norm_folder.split(os.sep)

    log_parts = None
    for i in range(len(parts) - 1, -1, -1):
        if parts[i].lower() == "check":
            log_parts = parts[:i] + ["log"] + parts[i + 1:]
            break

    if log_parts is None:
        raise FileNotFoundError(
            "Could not find a 'check' folder in the DEM_M path to map "
            f"across to 'log':\n{dem_m_path}"
        )

    log_folder = os.sep.join(log_parts)
    tlf_path = os.path.join(log_folder, event_stem + ".tlf")

    if not os.path.isfile(tlf_path):
        raise FileNotFoundError(
            f"Could not find the matching .tlf log file:\n{tlf_path}\n\n"
            f"(derived from DEM_M raster:\n{dem_m_path})"
        )

    return tlf_path


def find_materials_path(tlf_path):
    """
    Reads the .tlf log and pulls out the path of the materials file (.tmf
    or .csv) it references. A .tlf can name several other .tmf/.csv files
    that reuse the same File Unit number (e.g. a "_messages.csv" log, or
    a .tef event file), so the open/close block for each candidate is
    inspected and only the one containing "N...Processing: <id>,
    <mannings>, ..." rows — TUFLOW's echo of each material row while a
    materials file is open — is treated as the real materials file.
    """
    with open(tlf_path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()

    candidates = []

    for match in MATERIALS_OPEN_RE.finditer(text):
        path = match.group("path").strip()
        ext = os.path.splitext(path)[1].lower()

        if ext not in MATERIALS_EXTENSIONS:
            continue

        if MATERIALS_PROCESSING_RE.search(match.group("body")):
            candidates.append(path)

    if not candidates:
        raise ValueError(
            "No materials file (.tmf/.csv) with material rows was found "
            f"in log file:\n{tlf_path}"
        )

    materials_path = candidates[0]

    if not os.path.isfile(materials_path):
        raise FileNotFoundError(
            f"The materials file referenced in the log file could not be "
            f"found on disk:\n{materials_path}\n\n"
            f"(referenced from log:\n{tlf_path})"
        )

    return materials_path


# Splits a data row on comma or tab (either delimiter, or a mix), dropping
# empty tokens produced by repeated delimiters (e.g. ".tmf" rows with lots
# of blank ", ," placeholder fields).
_MATERIALS_FIELD_SPLIT_RE = re.compile(r"[,\t]")


def parse_materials_file(materials_path):
    """
    Parses a .tmf or .csv materials file into
    {id: (mannings_n_or_None, comment_or_None)}.

    Expected row shape: "ID, Manning's n, ..." with fields separated by
    commas or tabs, and an optional trailing comment either after a "!"
    on the data row (e.g. "1, 0.05, 0, 0 ! General open space") or as its
    own "!comment" field (e.g. "1\t0.06\t!Sparse trees"). Lines starting
    with "!" are skipped outright (banner text, commented-out material
    rows like "!7, 0.05, 0, 0 ! Mining"). A leading header row such as
    "Material ID, Manning's n" is tolerated silently; any *later* row
    that fails to parse sets a warning instead, so the caller can flag
    that labels might be off rather than failing outright.
    """
    mapping = {}
    warning = None

    with open(materials_path, "r", encoding="utf-8-sig", errors="replace") as f:
        lines = f.readlines()

    for raw_line in lines:
        line = raw_line.strip()

        if not line or line.startswith("!"):
            continue

        if "!" in line:
            data_part, comment_part = line.split("!", 1)
            comment = comment_part.strip() or None
        else:
            data_part = line
            comment = None

        fields = [
            field.strip()
            for field in _MATERIALS_FIELD_SPLIT_RE.split(data_part)
            if field.strip()
        ]

        if len(fields) < 2:
            if not mapping:
                continue  # likely a header row with too few real fields
            warning = "some rows had an unexpected number of fields — labels might be off"
            continue

        try:
            id_val = int(float(fields[0]))
        except ValueError:
            if not mapping:
                continue  # likely a header row (e.g. "Material ID, Manning's n")
            warning = "some material IDs could not be read as numbers — labels might be off"
            continue

        try:
            mannings = float(fields[1])
        except ValueError:
            warning = "some Manning's n values could not be read as numbers — labels might be off"
            mannings = None

        mapping[id_val] = (mannings, comment)

    if not mapping:
        raise ValueError(
            f"Materials file found but contained no readable ID / Manning's n rows:\n{materials_path}"
        )

    return mapping, warning


def style_dem_m(layer, iface):
    dem_m_path = layer.source()

    tlf_path = find_dem_m_tlf(dem_m_path)
    materials_path = find_materials_path(tlf_path)
    mapping, warning = parse_materials_file(materials_path)

    provider = layer.dataProvider()

    ids_sorted = sorted(mapping.keys())

    items = []
    for i, id_val in enumerate(ids_sorted):
        mannings, comment = mapping[id_val]
        color = QColor(SRC_PALETTE[i % len(SRC_PALETTE)])

        if mannings is not None:
            label = f"{id_val} | {mannings}"
        else:
            label = f"{id_val} | ?"

        if comment:
            label += f" | {comment}"

        items.append(QgsColorRampShader.ColorRampItem(id_val, color, label))

    shader_fn = QgsColorRampShader()
    shader_fn.setColorRampType(QgsColorRampShader.Exact)
    shader_fn.setColorRampItemList(items)

    raster_shader = QgsRasterShader()
    raster_shader.setRasterShaderFunction(shader_fn)

    renderer = QgsSingleBandPseudoColorRenderer(provider, 1, raster_shader)
    apply_renderer(layer, iface, renderer)

    msg = f"DEM_M styled — {len(ids_sorted)} materials from {os.path.basename(materials_path)}"

    if warning:
        msg += f" — WARNING: {warning}"

    return msg


# ===========================================================================
# H (water elevation) styling
# Min/max come from the raster itself and are rounded to "nice" numbers,
# then split into 6 equal-width classes. Repeated clicks toggle
# between stats from the whole raster and stats from the current visible
# map canvas extent (1st click = full, 2nd = zoom, 3rd = full, ...).
# ===========================================================================
H_TOGGLE_PROPERTY = "hugosmagiccolours/h_mode"

def _nice_step(magnitude_basis):
    """Pick a 'nice' rounding step based on the order of magnitude of the value."""
    if magnitude_basis < 10:
        return 1
    digits = len(str(int(magnitude_basis)))
    if digits <= 2:
        return 10
    return 5 * (10 ** (digits - 2))

def compute_nice_bounds(raw_min, raw_max):
    """
    Round raw_min/raw_max to nice whole numbers for a clean-looking legend.
    e.g. 144.441 - 202.63 -> 150 - 200. 1 - 200 -> 0 - 200.
    """
    if raw_min > raw_max:
        raw_min, raw_max = raw_max, raw_min

    magnitude_basis = max(abs(raw_min), abs(raw_max))
    step = _nice_step(magnitude_basis)

    nice_min = round(raw_min / step) * step
    nice_max = round(raw_max / step) * step

    # A step sized off the raw magnitude can collapse a narrow range (e.g.
    # a zoomed-in view where visible values vary only slightly) down to a
    # single value. When that happens, retry with a finer step sized to
    # the actual range instead, so tight ranges still round sensibly.
    if nice_min >= nice_max:
        range_span = raw_max - raw_min
        step = _nice_step(range_span) if range_span >= 1 else 1
        nice_min = round(raw_min / step) * step
        nice_max = round(raw_max / step) * step

    if nice_min >= nice_max:
        # Still degenerate (e.g. a near-flat raster) — widen by one step
        nice_max = nice_min + step

    return nice_min, nice_max

def _fmt_h(val, decimals=0):
    # Whole-number bands (decimals=0) round for a clean legend. Sub-1
    # bands (decimals=2) need the fractional digits shown, otherwise
    # zoomed-in classes like 8.33/8.66/8.99 all collapse to the same
    # "8" label and look identical/wrong.
    if decimals <= 0:
        return str(int(round(val)))
    return f"{val:.{decimals}f}"

def get_h_bounds(layer, iface, use_zoom):
    """
    Returns (min, max) either from the whole raster (use_zoom=False) or
    from the portion of the raster visible in the current map canvas
    extent (use_zoom=True). Falls back to whole-raster stats if the zoom
    extent can't be resolved for any reason.
    """
    provider = layer.dataProvider()

    if use_zoom and iface:
        try:
            canvas = iface.mapCanvas()
            extent = canvas.extent()
            canvas_crs = canvas.mapSettings().destinationCrs()

            if canvas_crs != layer.crs():
                transform = QgsCoordinateTransform(canvas_crs, layer.crs(), QgsProject.instance())
                extent = transform.transformBoundingBox(extent)

            extent = extent.intersect(layer.extent())

            if not extent.isEmpty():
                stats = provider.bandStatistics(1, QgsRasterBandStats.All, extent, 0)
                return stats.minimumValue, stats.maximumValue
        except Exception:
            pass  # fall through to whole-raster stats below

    stats = provider.bandStatistics(1, QgsRasterBandStats.All)
    return stats.minimumValue, stats.maximumValue

def style_h(layer, iface):
    mode = int(layer.customProperty(H_TOGGLE_PROPERTY, 0))

    # 0 = full, 6 bands
    # 1 = zoom, 6 bands
    # 2 = full, 10 bands
    # 3 = zoom, 10 bands

    use_zoom = mode in (1, 3)
    num_bands = 10 if mode in (2, 3) else 6
    colours = H_COLOURS_10 if num_bands == 10 else H_COLOURS_6

    raw_min, raw_max = get_h_bounds(layer, iface, use_zoom)
    nice_min, nice_max = compute_nice_bounds(raw_min, raw_max)

    width = (nice_max - nice_min) / float(num_bands)

    # Band width >= 1: snap every breakpoint (and the classification value
    # itself, not just the label) to a whole number — e.g. 8.00, 9.00,
    # 10.00 — so zoomed-out views get clean integer classes.
    #
    # Band width < 1: zoomed-in views produce fractional breakpoints like
    # 8.33 / 8.66 / 8.99 that are indistinguishable once rounded to whole
    # numbers (all show as "8"/"9"), so keep 2 decimal places instead —
    # both in the label and in the actual value used for classification.
    if width >= 1:
        decimals = 0
        nice_min_disp = round(nice_min)
        breakpoints = [round(nice_min + width * i) for i in range(1, num_bands)]
    else:
        decimals = 2
        nice_min_disp = round(nice_min, decimals)
        breakpoints = [round(nice_min + width * i, decimals) for i in range(1, num_bands)]

    items = []
    prev = nice_min_disp

    for brk, rgba in zip(breakpoints + [None], colours):
        r, g, b, a = rgba
        color = QColor(r, g, b, a)

        if brk is None:
            label = f"> {_fmt_h(prev, decimals)}"
            value = float("inf")
        else:
            if prev == nice_min_disp:
                label = f"<= {_fmt_h(brk, decimals)}"
            else:
                label = f"{_fmt_h(prev, decimals)} - {_fmt_h(brk, decimals)}"
            value = brk

        items.append(QgsColorRampShader.ColorRampItem(value, color, label))

        if brk is not None:
            prev = brk

    shader_fn = QgsColorRampShader()
    shader_fn.setColorRampType(QgsColorRampShader.Discrete)
    shader_fn.setColorRampItemList(items)

    raster_shader = QgsRasterShader()
    raster_shader.setRasterShaderFunction(shader_fn)

    provider = layer.dataProvider()
    renderer = QgsSingleBandPseudoColorRenderer(
        provider,
        1,
        raster_shader
    )

    apply_renderer(layer, iface, renderer)

    # Flip for next time this is run on the same layer
    layer.setCustomProperty(
        H_TOGGLE_PROPERTY,
        (mode + 1) % 4
    )

    extent_desc = "current zoom extent" if use_zoom else "full raster extent"

    return (
        f"H styled from {extent_desc} "
        f"using {num_bands} bands "
        f"({_fmt_h(nice_min, decimals)} - {_fmt_h(nice_max, decimals)})"
    )


# ===========================================================================
# Afflux styling
# Both Afflux variants use fixed, literal colour/value/label sets (not
# derived from raster stats) that simply toggle between two presets each
# time the tool is run again on the same layer.
# ===========================================================================
def _values_match(a, b, tol=1e-9):
    if a == float("inf") and b == float("inf"):
        return True
    if a == float("-inf") and b == float("-inf"):
        return True
    return abs(a - b) < tol

def get_current_literal_scheme_index(layer, schemes):
    """
    Returns the index into `schemes` that matches the layer's current
    renderer values, or None if it doesn't match any of them.
    """
    renderer = layer.renderer()

    if not isinstance(renderer, QgsSingleBandPseudoColorRenderer):
        return None

    try:
        shader = renderer.shader()
        shader_fn = shader.rasterShaderFunction()
        items = shader_fn.colorRampItemList()
    except Exception:
        return None

    current_entries = []
    for item in items:
        try:
            color = item.color
            current_entries.append((
                float(item.value),
                color.red(), color.green(), color.blue(), color.alpha()
            ))
        except Exception:
            return None

    for idx, scheme in enumerate(schemes):
        scheme_entries = [entry[:5] for entry in scheme]

        if len(scheme_entries) != len(current_entries):
            continue

        if all(
            _values_match(a[0], b[0]) and a[1:] == b[1:]
            for a, b in zip(scheme_entries, current_entries)
        ):
            return idx

    return None

def _apply_literal_scheme(layer, iface, schemes, ramp_type, status_label):
    current_idx = get_current_literal_scheme_index(layer, schemes)

    if current_idx is None:
        scheme_idx = 0
    else:
        scheme_idx = (current_idx + 1) % len(schemes)

    scheme = schemes[scheme_idx]

    items = []
    for value, r, g, b, a, label in scheme:
        items.append(
            QgsColorRampShader.ColorRampItem(
                value,
                QColor(r, g, b, a),
                label
            )
        )

    shader_fn = QgsColorRampShader()
    shader_fn.setColorRampType(ramp_type)
    shader_fn.setColorRampItemList(items)

    raster_shader = QgsRasterShader()
    raster_shader.setRasterShaderFunction(shader_fn)

    provider = layer.dataProvider()
    renderer = QgsSingleBandPseudoColorRenderer(
        provider,
        1,
        raster_shader
    )

    apply_renderer(layer, iface, renderer)

    return f"{status_label} styled [Scheme {scheme_idx + 1}/{len(schemes)}]"

def style_afflux_wd(layer, iface):
    return _apply_literal_scheme(
        layer,
        iface,
        AFFLUX_WD_SCHEMES,
        QgsColorRampShader.Exact,
        "Afflux (Was Wet/Dry)"
    )

def style_afflux(layer, iface):
    return _apply_literal_scheme(
        layer,
        iface,
        AFFLUX_SCHEMES,
        QgsColorRampShader.Discrete,
        "Afflux"
    )


def style_zaem1(layer, iface):
    return _apply_literal_scheme(
        layer,
        iface,
        ZAEM1_SCHEMES,
        QgsColorRampShader.Exact,
        "ZAEM1"
    )


# ===========================================================================
# SRC styling
# ===========================================================================
def find_src_csv(src_path):
    folder = os.path.dirname(src_path)
    basename = os.path.basename(src_path)
    stem = os.path.splitext(basename)[0]

    candidates = [
        os.path.join(folder, stem.replace("_Median_Src", "") + "_Src_legend.csv"),
        os.path.join(folder, stem + "_Src_legend.csv"),
        os.path.join(folder, basename + "_src_legend.csv"),
        os.path.join(folder, stem.replace("_Src", "").replace("_src", "") + ".tif_src_legend.csv"),
        os.path.join(folder, stem.replace("_Src", "").replace("_src", "") + "_src_legend.csv"),
        os.path.join(folder, stem + "_legend.csv"),
    ]

    for c in candidates:
        if os.path.isfile(c):
            return c

    all_csvs = [f for f in os.listdir(folder) if f.lower().endswith(".csv")]
    hint = (
        "\n\nCSV files in same folder:\n" + "\n".join(all_csvs[:5]) +
        (f"\n... and {len(all_csvs) - 5} more" if len(all_csvs) > 5 else "")
        if all_csvs else "\n\nNo CSV files found in the same folder."
    )
    raise FileNotFoundError(
        f"Could not find the companion legend CSV.\n\n"
        f"Folder: {folder}\nTried:\n" +
        "\n".join(os.path.basename(c) for c in candidates) + hint
    )


def style_src(layer, iface):
    src_path = layer.source()
    csv_path = find_src_csv(src_path)

    legend_map = {}
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        for row in csv.reader(f):
            if len(row) >= 2:
                try:
                    val = int(float(row[0].strip()))
                    legend_map[val] = os.path.basename(row[1].strip())
                except ValueError:
                    pass

    if not legend_map:
        raise ValueError(f"CSV found but contained no readable data:\n{csv_path}")

    provider = layer.dataProvider()
    stats = provider.bandStatistics(1, QgsRasterBandStats.All)
    unique_vals = list(range(int(stats.minimumValue), int(stats.maximumValue) + 1))

    items = []
    for i, val in enumerate(unique_vals):
        color = QColor(SRC_PALETTE[i % len(SRC_PALETTE)])
        label = f"{val} | {legend_map.get(val, os.path.basename(src_path))}"
        items.append(QgsColorRampShader.ColorRampItem(val, color, label))

    shader_fn = QgsColorRampShader()
    shader_fn.setColorRampType(QgsColorRampShader.Exact)
    shader_fn.setColorRampItemList(items)

    raster_shader = QgsRasterShader()
    raster_shader.setRasterShaderFunction(shader_fn)

    renderer = QgsSingleBandPseudoColorRenderer(provider, 1, raster_shader)
    apply_renderer(layer, iface, renderer)

    return f"SRC styled — {len(unique_vals)} values from {os.path.basename(csv_path)}"


# ===========================================================================
# Dispatcher
# ===========================================================================
def apply_magic_colours(layer, iface):
    """Detect raster type and route to the correct styler. Returns status string."""
    raster_type, err = get_raster_type(layer)
    if raster_type is None:
        raise ValueError(err)

    if raster_type == "depth":
        return style_depth(layer, iface)

    if raster_type == "velocity":
        return style_velocity(layer, iface)

    if raster_type == "src":
        return style_src(layer, iface)

    if raster_type == "afflux_wd":
        return style_afflux_wd(layer, iface)

    if raster_type == "afflux":
        return style_afflux(layer, iface)

    if raster_type == "z0":
        return style_z0(layer, iface)

    if raster_type == "zaem1":
        return style_zaem1(layer, iface)

    if raster_type == "h":
        return style_h(layer, iface)

    if raster_type == "dem_m":
        return style_dem_m(layer, iface)

    if raster_type == "dem":
        return style_dem(layer, iface)

    raise ValueError(f"No styler implemented yet for type: {raster_type}")


# ===========================================================================
# Processing algorithm
# ===========================================================================
class MagicColoursAlgorithm(QgsProcessingAlgorithm):
    INPUT = "INPUT"

    def name(self):        return "magiccolours"
    def displayName(self): return "Hugo's Magic Colours"
    def group(self):       return "Hugo's Magic Colours"
    def groupId(self):     return "hugosmagiccolours"
    def createInstance(self): return MagicColoursAlgorithm()
    def icon(self):        return make_icon()

    def shortHelpString(self):
        return "Applies smart symbology to hydraulic rasters based on filename suffix."

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, "Raster layer"))

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        try:
            msg = apply_magic_colours(layer, iface=None)
            feedback.pushInfo(msg)
        except (ValueError, FileNotFoundError) as e:
            feedback.reportError(str(e), fatalError=True)
        return {}


class MagicColoursProvider(QgsProcessingProvider):
    def loadAlgorithms(self): self.addAlgorithm(MagicColoursAlgorithm())
    def id(self):   return "hugosmagiccolours"
    def name(self): return "Hugo's Magic Colours"
    def icon(self): return make_icon()


# ===========================================================================
# Plugin entry point
# ===========================================================================
class MagicColoursPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.toolbar = None
        self.action = None
        self.provider = None
        self.transparency_filter = None
        self.michael_filter = None

        # DEM rapid triple-click detection
        self._dem_click_times = []

    def initGui(self):
        # Remove any orphaned toolbar from Plugin Reloader
        from qgis.PyQt.QtWidgets import QToolBar
        for existing in self.iface.mainWindow().findChildren(QToolBar, "HugosMagicColoursToolbar"):
            self.iface.mainWindow().removeToolBar(existing)
            existing.hide()
            sip.delete(existing)

        icon = make_icon()

        self.toolbar = QToolBar("Hugo's Magic Colours")
        self.toolbar.setObjectName("HugosMagicColoursToolbar")
        self.toolbar.setIconSize(QSize(32, 32))
        self.iface.mainWindow().addToolBar(self.toolbar)

        self.action = QAction(icon, "Hugo's Magic Colours", self.iface.mainWindow())
        self.action.setToolTip(
            "Apply smart symbology to the selected raster(s)\n"
            "Works on every raster highlighted in the Layers panel at once.\n"
            "Supports:\n"
            " • Depth (_d_Max)\n"
            " • Velocity (_V_Max)\n"
            " • SRC (_Src)\n"
            " • Afflux (contains 'afflux', optionally '_wd')\n"
            " • Z0 (_Z0)\n"
            " • ZAEM1 (_ZAEM1)\n"
            " • H — water elevation (_H)\n"
            " • DEM_M — materials DEM (_DEM_M), styled from the matching .tlf/.tmf\n"
            " • DEM (contains 'DEM')\n"
            "Also in Processing Toolbox → Hugo's Magic Colours"
        )
        self.action.triggered.connect(self.run)
        self.toolbar.addAction(self.action)

        self.iface.addPluginToRasterMenu("&Hugo's Magic Colours", self.action)

        self.provider = MagicColoursProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

        # Transparency: hold Alt+T, then tap 0-9 (0%-90%) or F (100%) while
        # still holding. Installed on the QApplication instance so it sees
        # key events regardless of which panel/canvas currently has focus.
        self.transparency_filter = TransparencyKeyFilter(self.iface)
        QgsApplication.instance().installEventFilter(self.transparency_filter)

        self.michael_filter = MichaelKeyFilter(self.iface)
        QgsApplication.instance().installEventFilter(self.michael_filter)

    def unload(self):
        if self.action:
            self.iface.removePluginRasterMenu(
                "&Hugo's Magic Colours",
                self.action
            )
            self.action = None

        if self.toolbar:
            self.iface.mainWindow().removeToolBar(self.toolbar)
            sip.delete(self.toolbar)
            self.toolbar = None

        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None

        if self.transparency_filter:
            QgsApplication.instance().removeEventFilter(self.transparency_filter)
            self.transparency_filter = None

        if self.michael_filter:
            QgsApplication.instance().removeEventFilter(
                self.michael_filter
            )
            self.michael_filter = None

    def _dem_triple_click(self):
        """
        Detect three rapid clicks of the Hugo's Magic Colours button.

        Returns True only when the current click completes a triple-click
        within DEM_TRIPLE_CLICK_INTERVAL milliseconds.
        """

        from qgis.PyQt.QtCore import QDateTime

        now = QDateTime.currentMSecsSinceEpoch()

        # Keep only clicks within the allowed interval.
        self._dem_click_times = [
            t for t in self._dem_click_times
            if now - t <= DEM_TRIPLE_CLICK_INTERVAL
        ]

        self._dem_click_times.append(now)

        # Triple-click detected.
        if len(self._dem_click_times) >= 3:
            self._dem_click_times = []
            return True

        return False

    def run(self):

        layers = get_selected_or_active_layers(self.iface)

        raster_layers = [
            l for l in layers
            if isinstance(l, QgsRasterLayer)
        ]

        if not raster_layers:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Hugo's Magic Colours",
                "Please select one or more raster layers in the Layers panel first."
            )
            return

        # ===============================================================
        # RAPID TRIPLE-CLICK DETECTION
        #
        # Only relevant when at least one selected raster is a (plain) DEM.
        # DEM_M is a distinct type and is never routed through the
        # triple-click/rainbow-ramp toggle used by ordinary DEMs.
        # ===============================================================

        dem_layers = []

        for layer in raster_layers:
            raster_type, _ = get_raster_type(layer)

            if raster_type == "dem":
                dem_layers.append(layer)

        rainbow_toggle = False

        if dem_layers:
            rainbow_toggle = self._dem_triple_click()

        # ===============================================================
        # STYLE RASTERS
        # ===============================================================

        successes = []
        failures = []

        for layer in raster_layers:

            try:

                raster_type, _ = get_raster_type(layer)

                # Plain DEMs get the special triple-click behaviour.
                # DEM_M is excluded from this and always routed through
                # apply_magic_colours -> style_dem_m instead.
                if raster_type == "dem":

                    msg = style_dem(
                        layer,
                        self.iface,
                        rainbow_toggle=rainbow_toggle
                    )

                else:

                    msg = apply_magic_colours(
                        layer,
                        self.iface
                    )

                successes.append(
                    f"{layer.name()}: {msg}"
                )

            except (ValueError, FileNotFoundError) as e:

                failures.append(
                    f"{layer.name()}: {e}"
                )

        # ===============================================================
        # STATUS MESSAGES
        # ===============================================================

        if successes and not failures:

            if len(successes) == 1:

                self.iface.messageBar().pushSuccess(
                    "Hugo's Magic Colours",
                    successes[0]
                )

            else:

                self.iface.messageBar().pushSuccess(
                    "Hugo's Magic Colours",
                    f"Styled {len(successes)} rasters"
                )

        elif successes and failures:

            self.iface.messageBar().pushWarning(
                "Hugo's Magic Colours",
                f"Styled {len(successes)} raster(s), "
                f"{len(failures)} failed — see details"
            )

            QMessageBox.warning(
                self.iface.mainWindow(),
                "Hugo's Magic Colours",
                "Some layers could not be styled:\n\n"
                + "\n\n".join(failures)
            )

        else:

            QMessageBox.warning(
                self.iface.mainWindow(),
                "Hugo's Magic Colours",
                "\n\n".join(failures)
            )