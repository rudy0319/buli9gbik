# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterNumber,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterString,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsProcessingException,
    QgsRasterLayer,
    QgsVectorLayer,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsRasterBandStats,
    QgsVectorFileWriter
)

from qgis import processing
import os, inspect, uuid, tempfile
from decimal import Decimal, getcontext, ROUND_CEILING

import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator, MaxNLocator


# ---------------------------------------------------------------------
# Helper functions (plot logic)
# ---------------------------------------------------------------------
def scale_storage(vals):
    vmax = max(vals)
    if vmax >= 1e9:
        return [v / 1e6 for v in vals], "GL"
    elif vmax >= 1e6:
        return [v / 1e3 for v in vals], "ML"
    return vals, "m³"

def scale_area(vals):
    vmax = max(vals)
    if vmax >= 1e7:
        return [v / 1e6 for v in vals], "km²"
    elif vmax >= 1e6:
        return [v / 1e4 for v in vals], "ha"
    return vals, "m²"


class StageStorageAlgorithm(QgsProcessingAlgorithm):

    INPUT_DEM = 'INPUT_DEM'
    DEM_CRS_OVERRIDE = 'DEM_CRS_OVERRIDE'
    INPUT_POLYGON = 'INPUT_POLYGON'
    ID_FIELD = 'ID_FIELD'
    INCREMENT = 'INCREMENT'
    BASE_LEVEL = 'BASE_LEVEL'
    OUTPUT_FOLDER = 'OUTPUT_FOLDER'
    OUTPUT_NAME = 'OUTPUT_NAME'
    CREATE_PLOT = 'CREATE_PLOT'

    # ------------------------------------------------------------
    def initAlgorithm(self, config=None):

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT_DEM, 'Input DEM raster layer'
        ))

        self.addParameter(QgsProcessingParameterCrs(
            self.DEM_CRS_OVERRIDE,
            'Override cutline CRS (DEM CRS)',
            optional=True
        ))

        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT_POLYGON,
            'Polygon layer (optional – one output per feature)',
            optional=True
        ))

        self.addParameter(QgsProcessingParameterField(
            self.ID_FIELD,
            'Feature field for ID',
            parentLayerParameterName=self.INPUT_POLYGON,
            optional=True
        ))

        self.addParameter(QgsProcessingParameterNumber(
            self.INCREMENT,
            'Stage increment (m)',
            QgsProcessingParameterNumber.Double,
            1.0,
            minValue=0.0001
        ))

        self.addParameter(QgsProcessingParameterNumber(
            self.BASE_LEVEL,
            'Base level (m AHD)',
            QgsProcessingParameterNumber.Double,
            None,
            optional=True
        ))

        self.addParameter(QgsProcessingParameterString(
            self.OUTPUT_NAME,
            'Output file base name',
            defaultValue='Stage_Storage'
        ))

        self.addParameter(QgsProcessingParameterFolderDestination(
            self.OUTPUT_FOLDER,
            'Output folder'
        ))

        self.addParameter(QgsProcessingParameterBoolean(
            self.CREATE_PLOT,
            'Create stage–storage–area plot',
            defaultValue=False
        ))

    # ------------------------------------------------------------
    def generate_stages(self, base, zmax, inc):
        getcontext().prec = 12
        base = Decimal(str(base))
        zmax = Decimal(str(zmax))
        inc = Decimal(str(inc))

        levels = [base]
        next_lvl = (base / inc).to_integral_value(rounding=ROUND_CEILING) * inc
        if next_lvl <= base:
            next_lvl += inc

        while next_lvl <= zmax:
            levels.append(next_lvl)
            next_lvl += inc

        return [float(v) for v in levels]

    # ------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):

        dem = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        if not dem:
            raise QgsProcessingException('Invalid DEM')

        dem_path = dem.source()

        user_override = self.parameterAsCrs(parameters, self.DEM_CRS_OVERRIDE, context)
        if user_override and user_override.isValid():
            effective_crs = user_override
            feedback.pushInfo(f'Using user-specified override CRS: {effective_crs.authid()}')
        elif dem.crs().isValid():
            effective_crs = dem.crs()
            feedback.pushInfo(f'Using DEM CRS as automatic cutline override: {effective_crs.authid()}')
        else:
            effective_crs = None

        poly_source = self.parameterAsSource(parameters, self.INPUT_POLYGON, context)
        poly_layer = self.parameterAsVectorLayer(parameters, self.INPUT_POLYGON, context)
        poly_path = poly_layer.source() if poly_layer else ''

        inc = self.parameterAsDouble(parameters, self.INCREMENT, context)
        base_param = parameters.get(self.BASE_LEVEL)
        id_field = self.parameterAsString(parameters, self.ID_FIELD, context)
        create_plot = self.parameterAsBoolean(parameters, self.CREATE_PLOT, context)

        out_folder = self.parameterAsString(parameters, self.OUTPUT_FOLDER, context)
        base_name = self.parameterAsString(parameters, self.OUTPUT_NAME, context)
        os.makedirs(out_folder, exist_ok=True)

        if not poly_source:
            out_xlsx = os.path.join(out_folder, f'{base_name}.xlsx')
            self.write_stage_storage(
                dem, dem_path, '', '',
                inc, base_param,
                out_xlsx,
                create_plot,
                effective_crs,
                feedback, context
            )
            return {self.OUTPUT_FOLDER: out_folder}

        for feat in poly_source.getFeatures():
            fid = str(feat[id_field]) if id_field else str(feat.id())
            out_xlsx = os.path.join(out_folder, f'{base_name}_{fid}.xlsx')

            self.write_stage_storage(
                dem, dem_path, poly_path,
                fid, inc, base_param,
                out_xlsx,
                create_plot,
                effective_crs,
                feedback, context,
                feature=feat,
                poly_source=poly_source
            )

        return {self.OUTPUT_FOLDER: out_folder}

    # ------------------------------------------------------------
    def write_stage_storage(
        self, dem, dem_path, poly_path, fid, inc, base_param,
        out_xlsx, create_plot, effective_crs,
        feedback, context, feature=None, poly_source=None
    ):

        # ---- clipping ----
        if feature:
            if effective_crs is None:
                raise QgsProcessingException(
                    'Stage Storage failed during raster clipping.\n'
                    'No valid CRS could be determined.'
                )

            clip_path = os.path.join(
                tempfile.gettempdir(),
                f'stage_clip_{uuid.uuid4().hex}.tif'
            )

            mask = QgsVectorLayer('Polygon', 'mask', 'memory')
            mask.setCrs(poly_source.sourceCrs())
            mask.dataProvider().addAttributes(poly_source.fields())
            mask.updateFields()

            fmask = QgsFeature(mask.fields())
            fmask.setGeometry(feature.geometry())
            fmask.setAttributes(feature.attributes())
            mask.dataProvider().addFeature(fmask)

            processing.run(
                'gdal:cliprasterbymasklayer',
                {
                    'INPUT': dem,
                    'MASK': mask,
                    'SOURCE_CRS': effective_crs,
                    'CROP_TO_CUTLINE': True,
                    'KEEP_RESOLUTION': True,
                    'NODATA': -9999,
                    'OUTPUT': clip_path
                },
                context=context,
                is_child_algorithm=True
            )

            r = QgsRasterLayer(clip_path, 'clipped')
            if not r.isValid():
                raise QgsProcessingException('GDAL clipping failed due to CRS issues.')
        else:
            r = dem

        stats = r.dataProvider().bandStatistics(
            1, QgsRasterBandStats.All, r.extent(), 0
        )

        zmin, zmax = stats.minimumValue, stats.maximumValue

        subtract_base = False
        if base_param is None:
            base = zmin
        else:
            base = float(base_param)
            if base < zmin or base > zmax:
                feedback.reportError(
                    f'Feature ID {fid}: Base level {base:.3f} m is outside DEM range '
                    f'({zmin:.3f} m to {zmax:.3f} m). Adopting minimum stage level '
                    f'of {zmin:.3f} m.'
                )
                base = zmin
            else:
                subtract_base = True
                feedback.reportError(
                    f'Feature ID {fid}: Base level {base:.3f} m adopted — '
                    'storage, area and pixel count calculated relative to this level.'
                )

        available_range = zmax - base
        if inc > available_range:
            feedback.reportError(
                f'Feature ID {fid}: Stage increment ({inc:.3f} m) is greater than '
                f'the available elevation range ({available_range:.3f} m). '
                'Only a single stage will be generated.'
            )

        stages = self.generate_stages(base, zmax, inc)

        stage_vals, storage_vals, area_vals = [], [], []
        base_vol, base_area, base_pix = 0, 0, 0

        if subtract_base:
            base_res = processing.run(
                'native:rastersurfacevolume',
                {'INPUT': r, 'BAND': 1, 'LEVEL': base, 'METHOD': 1},
                context=context, is_child_algorithm=True
            )
            base_vol = abs(base_res['VOLUME'])
            base_area = base_res['AREA']
            base_pix = base_res['PIXEL_COUNT']

        fields = QgsFields()
        fields.append(QgsField('Input_DEM_Path', 10, 'string'))
        fields.append(QgsField('Input_Polygon_Path_and_ID', 10, 'string'))
        fields.append(QgsField('Stage_m', 6, 'double'))
        fields.append(QgsField('Storage_m3', 6, 'double'))
        fields.append(QgsField('Area_m2', 6, 'double'))
        fields.append(QgsField('Pixel_count', 4, 'int'))

        vl = QgsVectorLayer('None', 'Stage_Storage', 'memory')
        vl.dataProvider().addAttributes(fields)
        vl.updateFields()

        for i, stage in enumerate(stages):

            res = processing.run(
                'native:rastersurfacevolume',
                {'INPUT': r, 'BAND': 1, 'LEVEL': stage, 'METHOD': 1},
                context=context, is_child_algorithm=True
            )

            storage = abs(res['VOLUME']) - base_vol if subtract_base else abs(res['VOLUME'])
            area = res['AREA'] - base_area if subtract_base else res['AREA']
            pixels = res['PIXEL_COUNT'] - base_pix if subtract_base else res['PIXEL_COUNT']

            storage = max(storage, 0)
            area = max(area, 0)
            pixels = max(pixels, 0)

            stage_vals.append(stage)
            storage_vals.append(storage)
            area_vals.append(area)

            poly_cell = None
            if i == 0:
                poly_cell = poly_path
            elif i == 1 and fid:
                poly_cell = fid

            f = QgsFeature(fields)
            f.setAttributes([
                dem_path if i == 0 else None,
                poly_cell,
                stage,
                storage,
                area,
                pixels
            ])
            vl.dataProvider().addFeature(f)

        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = 'XLSX'
        opts.layerName = 'Stage Storage'
        opts.action = QgsVectorFileWriter.CreateOrOverwriteFile

        QgsVectorFileWriter.writeAsVectorFormatV3(
            vl, out_xlsx,
            context.transformContext(),
            opts
        )

        # ---- plotting + script export ----
        if create_plot and len(stage_vals) > 1:

            storage_s, su = scale_storage(storage_vals)
            area_s, au = scale_area(area_vals)

            fig, ax1 = plt.subplots()

            ax1.plot(stage_vals, storage_s, color='tab:blue')
            ax1.set_xlabel('Stage (m AHD)')
            ax1.set_ylabel(f'Storage ({su})', color='tab:blue')
            ax1.tick_params(axis='y', labelcolor='tab:blue')
            ax1.yaxis.set_major_locator(MaxNLocator(nbins=6))
            ax1.yaxis.set_minor_locator(AutoMinorLocator(5))
            ax1.minorticks_on()
            ax1.grid(True, which='major')
            ax1.grid(True, which='minor', alpha=0.3)

            ax2 = ax1.twinx()
            ax2.plot(stage_vals, area_s, color='tab:green')
            ax2.set_ylabel(f'Area ({au})', color='tab:green')
            ax2.tick_params(axis='y', labelcolor='tab:green')
            ax2.yaxis.set_major_locator(MaxNLocator(nbins=6))
            ax2.yaxis.set_minor_locator(AutoMinorLocator(5))
            ax2.minorticks_on()

            fig.tight_layout()
            fig.savefig(out_xlsx.replace('.xlsx', '.png'), dpi=300)
            plt.close(fig)

            # ---- save standalone plot script ----
            with open(out_xlsx.replace('.xlsx', '_plot.py'), 'w') as f:
                f.write(f"""# Auto-generated Stage–Storage–Area plot
# Edit freely (colours, labels, titles)

import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator, MaxNLocator

xlsx_path = "{os.path.basename(out_xlsx)}"
df = pd.read_excel(xlsx_path)

stage = df["Stage_m"]
storage = df["Storage_m3"]
area = df["Area_m2"]

def scale_storage(vals):
    vmax = vals.max()
    if vmax >= 1e9:
        return vals / 1e6, "GL"
    elif vmax >= 1e6:
        return vals / 1e3, "ML"
    return vals, "m³"

def scale_area(vals):
    vmax = vals.max()
    if vmax >= 1e7:
        return vals / 1e6, "km²"
    elif vmax >= 1e6:
        return vals / 1e4, "ha"
    return vals, "m²"

storage_s, su = scale_storage(storage)
area_s, au = scale_area(area)

fig, ax1 = plt.subplots()

ax1.plot(stage, storage_s, color='tab:blue')
ax1.set_xlabel('Stage (m AHD)')
ax1.set_ylabel(f'Storage ({{su}})', color='tab:blue')
ax1.tick_params(axis='y', labelcolor='tab:blue')
ax1.yaxis.set_major_locator(MaxNLocator(nbins=6))
ax1.yaxis.set_minor_locator(AutoMinorLocator(5))
ax1.minorticks_on()
ax1.grid(True, which='major')
ax1.grid(True, which='minor', alpha=0.3)

ax2 = ax1.twinx()
ax2.plot(stage, area_s, color='tab:green')
ax2.set_ylabel(f'Area ({{au}})', color='tab:green')
ax2.tick_params(axis='y', labelcolor='tab:green')
ax2.yaxis.set_major_locator(MaxNLocator(nbins=6))
ax2.yaxis.set_minor_locator(AutoMinorLocator(5))
ax2.minorticks_on()

plt.tight_layout()
plt.savefig(xlsx_path.replace('.xlsx', '.png'), dpi=300)
plt.show()
""")

    # ------------------------------------------------------------
    def name(self):
        return 'stagestorage'

    def displayName(self):
        return 'Stage Storage'

    def createInstance(self):
        return StageStorageAlgorithm()

    def tr(self, text):
        return QCoreApplication.translate('Processing', text)

    def icon(self):
        folder = os.path.dirname(inspect.getfile(inspect.currentframe()))
        return QIcon(os.path.join(folder, 'logo.png'))
    
    def shortHelpString(self):
        return """
        Creates a stage–storage relationship from a DEM, with optional polygon clipping, and exports the results to Excel. Optional plots and reusable plotting scripts can also be generated.<br><br>

        <b><u>Key Features:</u></b>
        <ul>
            <li><i>Supports full DEM or polygon-clipped analysis</i></li>
            <li><i>Multiple polygons processed automatically (one Excel file per feature)</i></li>
            <li><i>User-defined output file base name</i></li>
            <li><i>Optional base level with storage calculated relative to that level</i></li>
            <li><i>Optional stage–storage–area plot generation</i></li>
            <li><i>Standalone Python plotting script saved for post-editing</i></li>
        </ul>

        <b><u>Inputs:</u></b>
        <ul>
            <li><b>DEM raster:</b>
                <i>Elevation raster used to calculate the stage–storage curve (e.g. a mine pit or reservoir).</i>
                The raster should use a projected CRS for meaningful volume and area results.
                If the raster has no CRS defined (e.g. TUFLOW DEM_Z files), the tool will automatically adopt the assigned DEM CRS or a user-specified override for internal calculations.</li>

            <li><b>Override cutline CRS (DEM CRS):</b>
                <i>Optional CRS override used when clipping with polygons.</i>
                This is useful when rasters do not contain embedded CRS metadata but are known to be correctly located (e.g. TUFLOW outputs).
                If not supplied and the DEM has a valid CRS, the DEM CRS is adopted automatically.
                If neither is available, the tool will stop with an error.</li>

            <li><b>Polygon layer (Optional):</b>
                <i>Limits calculations to the area within each polygon feature.</i>
                If multiple features exist, one Excel file is created per feature.</li>

            <li><b>Feature field for ID (Optional):</b>
                <i>Attribute used to uniquely identify each polygon.</i>
                This value is appended to the output file name and written into the Excel file.</li>

            <li><b>Stage increment (m):</b>
                <i>Vertical step between stage levels (e.g. 0.5&nbsp;m).</i></li>

            <li><b>Base level (Optional):</b>
                <i>Elevation used as the reference (zero-storage) level.</i>
                If provided and within the DEM range, storage, area, and pixel counts are reported relative to this level.
                If outside the DEM range, the minimum DEM elevation is used instead and a warning is issued.</li>

            <li><b>Output file base name:</b>
                <i>Base name of the Excel output file.</i>
                Outputs are created as &lt;Name&gt;.xlsx (no polygons) or &lt;Name&gt;_ID.xlsx (with polygons).</li>
        </ul>

        <b><u>Outputs:</u></b>
        <ul>
            <li>Excel spreadsheets containing stage, storage volume, inundated area, and pixel count.</li>
            <li>Optional PNG plots showing stage vs storage and stage vs area with dual y-axes.</li>
            <li>Optional standalone Python plotting script (<i>_plot.py</i>) saved alongside the Excel file, allowing users to easily customise colours, labels, styles, or add titles later.</li>
        </ul>

        <b><u>Theory:</u></b>
        <ul>
            <li>Volumes are calculated using QGIS’s <i>Raster Surface Volume</i> algorithm.</li>
            <li>Storage represents the cumulative volume below each stage level.</li>
            <li>Area and pixel count represent the surface below each stage.</li>
            <li>Using a high-resolution, projected DEM is strongly recommended.</li>
            <li>Always sanity-check results for unusual elevations or increments.</li>
        </ul>

        <br>
        <i>For issues or enhancement requests, please contact Hugo O’Brien.</i>
        """