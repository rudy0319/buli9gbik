
# -*- coding: utf-8 -*-

"""
/***************************************************************************
 ManningsDownloader
                                 A QGIS plugin
 Downloads Sentinel-2 Land Cover Data from Esri's Living Atlas
 and creates a Manning's Roughness shapefile from it.
                              -------------------
        begin                : 2026-01-22
        email                : hugo.obrien@slrconsulting.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This script contains the provider code for the Manning's              *
 *   roughness and land classification downloader processing plugin.       *
 *                                                                         *
 ***************************************************************************/
"""

__author__ = 'Hugo OBrien'
__date__ = '2026-01-22'
__revision__ = '$Format:%H$'

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
from os import path

# Existing algorithms
from .mannings_downloader_algorithm import (
    DownloadFromAoi
)

class ManningsDownloaderProvider(QgsProcessingProvider):

    def __init__(self):
        """
        Default constructor.
        """
        QgsProcessingProvider.__init__(self)

    def unload(self):
        """
        Unloads the provider.
        """
        pass

    def loadAlgorithms(self):
        """
        Loads all algorithms belonging to this provider.
        """
        # Existing download/clip tools
        self.addAlgorithm(DownloadFromAoi())

    def id(self):
        """
        Returns the unique provider id, used for identifying the provider.
        """
        return 'ManningsDownloader'

    def name(self):
        """
        Returns the provider name.
        """
        return self.tr('Mannings Downloader')

    def icon(self):
        """
        Returns icon.
        """
        return QIcon(path.dirname(__file__) + "/resources/logo2.png")

