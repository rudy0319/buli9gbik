# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ManningsDownloader
                                 A QGIS plugin
 Downloads Sentinel-2 Land Cover Data from Esri's Living Atlas
 and creates a Manning's Roughness shapefile from it.
                              -------------------
        begin                : 2026-01-22
        email                : hugo.obrien@slrconsulting.com
 ***************************************************************************/

 This script initializes the plugin, making it known to QGIS.
"""

__author__ = 'Hugo OBrien'
__date__ = '2026-01-22'
__revision__ = '$Format:%H$'


# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    """Load ManningsDownloader class from file ManningsDownloader.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    #
    from .land_cover_downloader import LandCoverDownloaderPlugin
    return LandCoverDownloaderPlugin()
