# -*- coding: utf-8 -*-

"""
/***************************************************************************
 ManningsDownloader
                                 A QGIS plugin
 Downloads Sentinel-2 Land Cover Data from Esri's Living Atlas
 and creates a Manning's Roughness shapefile from it.
                              -------------------
        begin                : 2026-01-22
        email                : hugo.obrien@slrconsulting.com
 ***************************************************************************/

 /***************************************************************************
 *                                                                         *
 *   This script contains the main processing algorithms for the Manning's *
 *   roughness and land classification downloader processing plugin.       *
 *                                                                         *
 ***************************************************************************/
"""

__author__ = 'Hugo OBrien'
__date__ = '2026-01-22'
__revision__ = '$Format:%H$'


"""
Create Manning's Roughness from AOI (Area of Interest)
- Downloads/mosaics/clips Esri S2 Land Cover
- Builds TUFLOW 2d_mat_*.shp from mosaics
- Optionally writes a .tmf
- (Optional) Download OSM roads inside AOI
- (Optional) Download OSM water bodies
- (Optional) Download OSM wetlands
- (Optional) Download OSM streams
- (Optional) Download OSM sports fields
- (Optional) Download OSM or Microsoft building footprints
"""

from qgis.PyQt.QtCore import QCoreApplication, QUrl
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtNetwork import QNetworkRequest
from qgis.PyQt.QtWidgets import QDoubleSpinBox
from qgis import processing
from qgis.core import (
    QgsProcessing,
    QgsProcessingFeedback,
    QgsProject,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterVectorDestination,
    QgsProcessingParameterString,
    QgsProcessingParameterFile,
    QgsProcessingParameterNumber,
    QgsProcessingOutputVectorLayer,
    QgsVectorLayer,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsVectorFileWriter,
    QgsRasterLayer,
    QgsProcessingException,
    QgsNetworkAccessManager,
    QgsGeometry
)
from processing.gui.wrappers import WidgetWrapper
from qgis.gui import QgsFileWidget
from tempfile import TemporaryDirectory
from os import path
import os
import re
import uuid
import time

from .mannings_functions import downloadLandCoverRaster, mosaicAndClipRasters

# -----------------------------------------
# Microsoft Buildings helper (Planetary Computer)
# -----------------------------------------

def _ms_buildings_to_gpkg(aoi_layer, aoi_src_crs, scratch_folder, feedback):
    """
    Downloads Microsoft Building Footprints intersecting the AOI using Planetary Computer
    (STAC + Delta/Parquet), then clips and saves to a temporary GeoPackage.

    Returns: (gpkg_path, layer_name)

    Requires extra packages in the QGIS Python env:
      pip install planetary-computer pystac-client deltalake==0.17.2 geopandas shapely mercantile adlfs fsspec pyarrow

    Dataset notes:
    - 'ms-buildings' is provided in Delta/Parquet and partitioned by RegionName and level-9 'quadkey'.
    - Access is via signed SAS tokens provided by the Planetary Computer STAC asset.
    """
    try:
        import pandas as pd
        import geopandas as gpd
        import shapely.geometry as sgeom
        import shapely.ops as sops
        from shapely.wkt import loads as wkt_loads
        import mercantile

        import planetary_computer
        import pystac_client
        from deltalake import DeltaTable
    except Exception as ex:
        raise QgsProcessingException(
            "MS Buildings option requires extra Python packages:\n"
            "  pip install planetary-computer pystac-client deltalake==0.17.2 geopandas shapely mercantile adlfs fsspec pyarrow\n"
            f"Import error: {ex}"
        )

    # ---- Build a single shapely AOI polygon in WGS84
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    needs_tx = (aoi_src_crs != wgs84)
    tx = QgsCoordinateTransform(aoi_src_crs, wgs84, QgsProject.instance().transformContext()) if needs_tx else None

    shp_polys = []
    for f in aoi_layer.getFeatures():
        g = QgsGeometry(f.geometry())
        if g is None or g.isEmpty():
            continue
        if needs_tx:
            try:
                g = QgsGeometry(g)  # copy
                g.transform(tx)
            except Exception:
                continue
        # convert to WKT -> shapely
        wkt = g.asWkt()
        try:
            shp_polys.append(wkt_loads(wkt))
        except Exception:
            pass

    if not shp_polys:
        raise QgsProcessingException("AOI has no valid geometry for MS Buildings request.")

    aoi_union = sops.unary_union(shp_polys)
    minx, miny, maxx, maxy = aoi_union.bounds

    # ---- Open STAC & resolve the ms-buildings Delta table (with signed credentials)
    catalog = pystac_client.Client.open(
        "https://planetarycomputer.microsoft.com/api/stac/v1",
        modifier=planetary_computer.sign_inplace,
    )
    collection = catalog.get_collection("ms-buildings")
    asset = collection.assets["delta"]  # Delta table (recommended 2023-04-25+)
    storage_options = {
        "account_name": asset.extra_fields["table:storage_options"]["account_name"],
        "sas_token": asset.extra_fields["table:storage_options"]["credential"],
    }
    table = DeltaTable(asset.href, storage_options=storage_options)

    # ---- Discover intersecting regions via STAC (fallback to 'Australia' if none returned)
    search = catalog.search(
        collections=["ms-buildings"],
        intersects={
            "type": "Polygon",
            "coordinates": [[
                [minx, miny], [minx, maxy], [maxx, maxy], [maxx, miny], [minx, miny]
            ]]
        }
    )
    items = list(search.get_items())
    regions = sorted({it.properties.get("msbuildings:region") for it in items if it.properties.get("msbuildings:region")})
    if not regions:
        regions = ["Australia"]  # sensible default for AU projects

    # ---- Compute level-9 quadkeys covering the AOI bounds
    quadkeys = [str(mercantile.quadkey(t)) for t in mercantile.tiles(minx, miny, maxx, maxy, zooms=9)]

    # ---- Query Delta for matching parquet parts
    filters = [("RegionName", "in", regions), ("quadkey", "in", quadkeys)]
    uris = table.file_uris(filters)
    if not uris:
        raise QgsProcessingException("MS Buildings: no parquet partitions matched the AOI. Enlarge the AOI or check coordinates.")

    feedback.pushInfo(f"MS Buildings: matched {len(uris)} parquet part(s) in {regions}.")

    # ---- Read, clip, save to GPKG
    dfs = [gpd.read_parquet(u, storage_options=storage_options) for u in uris]
    gdf = gpd.GeoDataFrame(pd.concat(dfs, ignore_index=True), geometry="geometry", crs="EPSG:4326")
    subset = gdf.clip(aoi_union)

    from pathlib import Path as _Path
    gpkg_path = str(_Path(scratch_folder) / f"ms_buildings_{int(time.time())}_{uuid.uuid4().hex[:6]}.gpkg")
    layer_name = "ms_buildings"
    subset.to_file(gpkg_path, layer=layer_name, driver="GPKG")
    feedback.pushInfo(f"MS Buildings saved to temp GeoPackage: {gpkg_path}")

    return gpkg_path, layer_name


# ---------- Header-only wrapper (tight: bold title + solid line) ----------
class HeaderWrapper(WidgetWrapper):
    def createWidget(self):
        from qgis.PyQt.QtWidgets import QWidget, QLabel, QFrame, QVBoxLayout, QSizePolicy
        from qgis.PyQt.QtCore import Qt
        dv = getattr(self.parameterDefinition(), 'defaultValue', lambda: None)()
        dv = dv() if callable(dv) else dv
        title = (dv or 'Additional Features').splitlines()[0].strip()
        self._title = title

        root = QWidget()
        root.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        lay = QVBoxLayout(root)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)

        lbl = QLabel(title)
        lbl.setTextInteractionFlags(Qt.NoTextInteraction)
        lbl.setStyleSheet("font-weight: 600;")
        lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        line.setLineWidth(1)
        line.setMidLineWidth(0)
        line.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        line.setMinimumHeight(1)
        line.setMaximumHeight(2)

        lay.addWidget(lbl)
        lay.addWidget(line)

        root.setMinimumHeight(0)
        root.setMaximumHeight(24)
        return root

    def value(self):
        return getattr(self, '_title', None) or "HEADER"


# ---------- TMF path wrapper ----------
class TmfPathWrapper(WidgetWrapper):
    def createWidget(self):
        self._w = QgsFileWidget()
        self._w.setFilter('TUFLOW Material (*.tmf)')
        try:
            self._w.setStorageMode(QgsFileWidget.SaveFile)
        except Exception:
            pass
        self._w.setEnabled(False)
        return self._w

    def _get_wrapper_value(self, wr):
        for attr in ('parameterValue', 'value'):
            if hasattr(wr, attr):
                try:
                    return bool(getattr(wr, attr)())
                except Exception:
                    pass
        return False

    def postInitialize(self, wrappers):
        checkbox_wrapper = None
        for wr in wrappers:
            try:
                if wr.parameterDefinition().name() == 'GENERATE_TMF':
                    checkbox_wrapper = wr
                    break
            except Exception:
                pass
        if not checkbox_wrapper:
            return

        def sync_enabled():
            try:
                self._w.setEnabled(self._get_wrapper_value(checkbox_wrapper))
            except Exception:
                pass

        try:
            checkbox_wrapper.widgetValueHasChanged.connect(lambda *_: sync_enabled())
        except Exception:
            pass
        try:
            checkbox_wrapper.valueChanged.connect(lambda *_: sync_enabled())
        except Exception:
            pass
        sync_enabled()

    def value(self):
        w = getattr(self, 'widget', None)
        if callable(w):
            try:
                w = w()
            except Exception:
                pass
        if not w:
            w = getattr(self, '_w', None)
        return w.filePath() if w else ''


# ---------- SaveFile proxy wrapper ----------
class SaveShpPathWrapper(WidgetWrapper):
    def createWidget(self):
        w = QgsFileWidget()
        w.setFilter('ESRI Shapefile (*.shp)')
        try:
            w.setStorageMode(QgsFileWidget.SaveFile)
        except Exception:
            pass
        return w

    def _get_widget(self):
        w = getattr(self, 'widget', None)
        if callable(w):
            try:
                w = w()
            except Exception:
                pass
        return w

    def value(self):
        w = self._get_widget()
        return w.filePath() if w else ''

    def setValue(self, value):
        w = self._get_widget()
        if w:
            try:
                w.setFilePath(value or '')
            except Exception:
                pass


# ---------- Roads buffer wrapper ----------
class RoadsBufferWrapper(WidgetWrapper):
    def createWidget(self):
        self._w = QDoubleSpinBox()
        self._w.setDecimals(3)
        self._w.setMinimum(0.0)
        self._w.setMaximum(1e6)
        self._w.setSingleStep(0.1)
        self._w.setValue(4.0)
        self._w.setEnabled(False)
        return self._w

    def _get_wrapper_value(self, wr):
        for attr in ('parameterValue', 'value'):
            if hasattr(wr, attr):
                try:
                    return bool(getattr(wr, attr)())
                except Exception:
                    pass
        return False

    def postInitialize(self, wrappers):
        roads_checkbox_wrapper = None
        for wr in wrappers:
            try:
                if wr.parameterDefinition().name() == 'GET_ROADS':
                    roads_checkbox_wrapper = wr
                    break
            except Exception:
                pass
        if not roads_checkbox_wrapper:
            return

        def sync_enabled():
            try:
                self._w.setEnabled(self._get_wrapper_value(roads_checkbox_wrapper))
            except Exception:
                pass

        try:
            roads_checkbox_wrapper.widgetValueHasChanged.connect(lambda *_: sync_enabled())
        except Exception:
            pass
        try:
            roads_checkbox_wrapper.valueChanged.connect(lambda *_: sync_enabled())
        except Exception:
            pass
        sync_enabled()

    def value(self):
        return float(self._w.value()) if hasattr(self, '_w') and self._w is not None else 4.0


# ---------- Streams buffer wrapper ----------
class StreamsBufferWrapper(WidgetWrapper):
    def createWidget(self):
        self._w = QDoubleSpinBox()
        self._w.setDecimals(3)
        self._w.setMinimum(0.0)
        self._w.setMaximum(1e6)
        self._w.setSingleStep(0.5)
        self._w.setValue(8.0)
        self._w.setEnabled(False)
        return self._w

    def _get_wrapper_value(self, wr):
        for attr in ('parameterValue', 'value'):
            if hasattr(wr, attr):
                try:
                    return bool(getattr(wr, attr)())
                except Exception:
                    pass
        return False

    def postInitialize(self, wrappers):
        streams_checkbox_wrapper = None
        for wr in wrappers:
            try:
                if wr.parameterDefinition().name() == 'GET_STREAMS':
                    streams_checkbox_wrapper = wr
                    break
            except Exception:
                pass
        if not streams_checkbox_wrapper:
            return

        def sync_enabled():
            try:
                self._w.setEnabled(self._get_wrapper_value(streams_checkbox_wrapper))
            except Exception:
                pass

        try:
            streams_checkbox_wrapper.widgetValueHasChanged.connect(lambda *_: sync_enabled())
        except Exception:
            pass
        try:
            streams_checkbox_wrapper.valueChanged.connect(lambda *_: sync_enabled())
        except Exception:
            pass
        sync_enabled()

    def value(self):
        return float(self._w.value()) if hasattr(self, '_w') and self._w is not None else 8.0


# ---------- Helpers ----------
def _unload_layers_pointing_to(target_path):
    try:
        norm_target = os.path.normcase(os.path.normpath(target_path))
        if not norm_target.lower().endswith('.shp'):
            return
        to_remove = []
        for lyr in list(QgsProject.instance().mapLayers().values()):
            try:
                ds = getattr(lyr, 'dataProvider', lambda: None)()
                uri = ds.dataSourceUri() if ds else ''
                if not uri:
                    uri = getattr(lyr, 'source', lambda: '')()
                if not uri:
                    continue
                base = uri.split('|', 1)[0]
                norm_uri = os.path.normcase(os.path.normpath(base))
                if norm_uri.lower().endswith('.shp') and norm_uri == norm_target:
                    to_remove.append(lyr.id())
            except Exception:
                pass
        if to_remove:
            QgsProject.instance().removeMapLayers(to_remove)
    except Exception:
        pass


def _aoi_extent_wgs84(aoi_layer):
    wgs84 = QgsCoordinateReferenceSystem('EPSG:4326')
    aoi_crs = aoi_layer.crs()
    needs_tx = aoi_crs != wgs84
    if needs_tx:
        tx = QgsCoordinateTransform(aoi_crs, wgs84, QgsProject.instance().transformContext())
        env = None
        for f in aoi_layer.getFeatures():
            g = QgsGeometry(f.geometry())
            if g is None or g.isEmpty():
                continue
            try:
                g.transform(tx)
            except Exception:
                continue
            if env is None:
                env = g.boundingBox()
            else:
                env.combineExtentWith(g.boundingBox())
        if env is None:
            raise QgsProcessingException("AOI has no valid geometry after reprojecting to EPSG:4326.")
    else:
        env = aoi_layer.extent()
    return env.yMinimum(), env.xMinimum(), env.yMaximum(), env.xMaximum()


def _apply_qml_style(vlayer, qml_path, feedback=None):
    try:
        if not vlayer or not vlayer.isValid():
            if feedback: feedback.pushWarning("Layer is invalid; cannot apply style.")
            return False
        if not os.path.exists(qml_path):
            if feedback: feedback.pushWarning(f"Style not found: {qml_path}")
            return False
        ok, msg = vlayer.loadNamedStyle(qml_path)
        if not ok:
            if feedback: feedback.pushWarning(f"Failed to load style: {msg or qml_path}")
            return False
        vlayer.triggerRepaint()
        if feedback: feedback.pushInfo(f"Applied style: {qml_path}")
        return True
    except Exception as ex:
        if feedback: feedback.pushWarning(f"Error applying style: {ex}")
        return False


def _has_features(vl):
    try:
        if not vl or not vl.isValid():
            return False
        fc = vl.featureCount()
        if fc is None or fc < 0:
            it = vl.getFeatures()
            for _ in it:
                return True
            return False
        return fc > 0
    except Exception:
        try:
            it = vl.getFeatures()
            for _ in it:
                return True
        except Exception:
            pass
        return False


# ---------- GeoPackage-first helpers ----------
def _unique_suffix():
    return f"{int(time.time())}_{uuid.uuid4().hex[:8]}"


def _set_gdal_env(scratch_folder):
    try:
        os.environ.setdefault("USE_CUSTOM_INDEXING", "NO")   # GDAL OSM indexing off
        os.environ.setdefault("CPL_TMPDIR", scratch_folder)  # Temp DB/cache location
    except Exception:
        pass


def _write_valid_overpass_xml(content_qb, out_path, feedback):
    """
    Accepts a QByteArray (from QNetworkReply.content()), validates it's real OSM XML
    by checking for '<osm' in the first bytes, and writes the file if valid.
    Returns True on success, False otherwise.
    """
    try:
        if content_qb is None:
            feedback.pushWarning("Overpass: payload is None.")
            return False

        # QByteArray -> bytes
        content_bytes = bytes(content_qb)

        if not content_bytes or len(content_bytes) < 50:
            feedback.pushWarning("Overpass: payload empty/tiny.")
            return False

        head = content_bytes[:512].decode('utf-8', 'ignore').lower()
        if "<osm" not in head:
            feedback.pushWarning("Overpass: payload is not OSM XML (no <osm> root) — likely a rate-limit or error page.")
            return False

        with open(out_path, "wb") as f:
            f.write(content_bytes)
        return True

    except Exception as ex:
        feedback.pushWarning(f"Overpass: failed to write XML: {ex}")
        return False


def _package_osm_to_gpkg(osm_path, gpkg_path, layer_names, context, feedback):
    """
    Read OSM sublayers and package them into a single GeoPackage.
    We package any VALID layer (even if empty) to avoid false negatives.
    Resulting layer names: OSM_<sublayer>.
    """
    layers_to_package = []
    for lname in layer_names:
        try:
            vl = QgsVectorLayer(f"{osm_path}|layername={lname}", f"OSM_{lname}", "ogr")
            if vl and vl.isValid():
                layers_to_package.append(vl)
                try:
                    fc = vl.featureCount()
                except Exception:
                    fc = -1
                feedback.pushInfo(f"OSM -> GPKG: adding layer 'OSM_{lname}' (featureCount={fc}).")
            else:
                feedback.pushInfo(f"OSM -> GPKG: layer '{lname}' invalid; skipping.")
        except Exception as ex:
            feedback.pushWarning(f"OSM -> GPKG: failed to read '{lname}': {ex}")

    if not layers_to_package:
        raise QgsProcessingException("OSM -> GPKG: No readable sublayers were exposed by the OSM driver. Check Overpass response.")

    try:
        processing.run(
            'native:package',
            {'LAYERS': layers_to_package, 'OUTPUT': gpkg_path, 'OVERWRITE': True},
            context=context, feedback=feedback
        )
        feedback.pushInfo(f"Packaged OSM into GeoPackage: {gpkg_path}")
        return gpkg_path
    except Exception as ex:
        raise QgsProcessingException(f"OSM -> GPKG packaging failed: {ex}")


# ---------- Algorithm ----------
class DownloadFromAoi(QgsProcessingAlgorithm):
    AOI = "AOI"; YEAR = "YEAR"; OUTPUT_SHP = "OUTPUT_SHP"
    MAKE_TMF = "GENERATE_TMF"; TMF_PATH = "TMF_PATH"
    GET_ROADS = "GET_ROADS"; ROADS_BUFFER_M = "ROADS_BUFFER_M"
    GET_WATER = "GET_WATER"; GET_WETLANDS = "GET_WETLANDS"
    GET_STREAMS = "GET_STREAMS"; STREAMS_BUFFER_M = "STREAMS_BUFFER_M"
    GET_SPORTS = "GET_SPORTS"
    MERGE_ADDITIONAL = "MERGE_ADDITIONAL"; OUTPUT = "OUTPUT"; OUTPUT_VEC = "OUTPUT_VEC"

    # NEW: Buildings tri-state enum (replaces GET_BUILDINGS + BUILDINGS_SOURCE)
    BUILDINGS_MODE = "BUILDINGS_MODE"  # 0=None, 1=OSM, 2=Microsoft

    CODEFILENAME = 'mannings_downloader_algorithm.py'
    YEARLIST = ['2017','2018','2019','2020','2021','2022','2023','2024','2025']

    CANONICAL_CLASSES = [
        (1, 'Water'), (2, 'Trees'), (4, 'Flooded vegetation'), (5, 'Crops'),
        (7, 'Built area'), (8, 'Bare ground'), (9, 'Snow/ice'), (10, 'Clouds'),
        (11, 'Rangeland'),
    ]
    N_BY_CODE = {1:0.030,2:0.080,4:0.060,5:0.045,7:0.100,8:0.050,9:0.010,10:None,11:0.045}
    LAST_BY_CODE = {1:1.0,2:0.0,4:0.0,5:0.0,7:0.8,8:0.0,9:0.0,10:None,11:0.0}

    def initAlgorithm(self, config=None):
        self.instance = QgsProject.instance()

        hdr = QgsProcessingParameterString("HEADER_ADDITIONAL_1",'',defaultValue=self.tr('Main Features'),multiLine=False,optional=False)
        hdr.setMetadata({'widget_wrapper': {'class': HeaderWrapper}}); self.addParameter(hdr)

        self.addParameter(QgsProcessingParameterFeatureSource(self.AOI,self.tr('1) Input AOI'),[QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterEnum(self.YEAR,self.tr('2) Data Collection Year (2017-2025)'),options=self.YEARLIST,defaultValue=8))

        p_out_proxy = QgsProcessingParameterString(self.OUTPUT_SHP,self.tr('3) Output shapefile (e.g. 2d_mat_NAME_R.shp)'),defaultValue='',multiLine=False,optional=False)
        p_out_proxy.setMetadata({'widget_wrapper': {'class': SaveShpPathWrapper}}); self.addParameter(p_out_proxy)

        p_vec = QgsProcessingParameterVectorDestination(name=self.OUTPUT_VEC,description=self.tr('Output vector destination (hidden)'))
        p_vec.setFlags(p_vec.flags() | p_vec.FlagHidden)
        try: p_vec.setDefaultValue('TEMPORARY_OUTPUT')
        except Exception: pass
        self.addParameter(p_vec)

        self.addParameter(QgsProcessingParameterBoolean(self.MAKE_TMF,self.tr('4) Generate TUFLOW .tmf file?'),defaultValue=False))
        tmf_param = QgsProcessingParameterFile(self.TMF_PATH,self.tr('Output TUFLOW .tmf'),
                                               behavior=QgsProcessingParameterFile.File,extension='tmf',optional=True)
        tmf_param.setMetadata({'widget_wrapper': {'class': TmfPathWrapper}}); self.addParameter(tmf_param)

        hdr2 = QgsProcessingParameterString("HEADER_ADDITIONAL",'',defaultValue=self.tr('Additional Features'),multiLine=False,optional=False)
        hdr2.setMetadata({'widget_wrapper': {'class': HeaderWrapper}}); self.addParameter(hdr2)

        self.addParameter(QgsProcessingParameterBoolean(self.GET_ROADS,self.tr('5) Get roads from OSM within AOI?'),defaultValue=False))
        buf = QgsProcessingParameterNumber(self.ROADS_BUFFER_M,self.tr('Road buffer distance (m) [recommended: 4]'),
                                           type=QgsProcessingParameterNumber.Double,defaultValue=4.0,minValue=0.0,optional=False)
        buf.setMetadata({'widget_wrapper': {'class': RoadsBufferWrapper}}); self.addParameter(buf)

        self.addParameter(QgsProcessingParameterBoolean(self.GET_WATER,self.tr('6) Get waterbodies from OSM within AOI?'),defaultValue=False))
        self.addParameter(QgsProcessingParameterBoolean(self.GET_WETLANDS,self.tr('7) Get wetlands from OSM within AOI?'),defaultValue=False))
        self.addParameter(QgsProcessingParameterBoolean(self.GET_STREAMS,self.tr('8) Get streams from OSM within AOI?'),defaultValue=False))
        s_buf = QgsProcessingParameterNumber(self.STREAMS_BUFFER_M,self.tr('Streams buffer distance (m) [recommended: 8]'),
                                             type=QgsProcessingParameterNumber.Double,defaultValue=8.0,minValue=0.0,optional=False)
        s_buf.setMetadata({'widget_wrapper': {'class': StreamsBufferWrapper}}); self.addParameter(s_buf)

        self.addParameter(QgsProcessingParameterBoolean(self.GET_SPORTS,self.tr('9) Get sports fields from OSM within AOI?'),defaultValue=False))

        # --- NEW: tri-state Buildings parameter (None / OSM / Microsoft)
        p_bldg_mode = QgsProcessingParameterEnum(
            self.BUILDINGS_MODE,
            self.tr('10) Get buildings?'),
            options=['None', 'OSM (Overpass)', 'Microsoft (MS Building Footprints)'],
            defaultValue=0
        )
        self.addParameter(p_bldg_mode)

        self.addParameter(QgsProcessingParameterBoolean(self.MERGE_ADDITIONAL,self.tr('11) Merge additional files with main output file?'),defaultValue=False))

        self.addOutput(QgsProcessingOutputVectorLayer(self.OUTPUT,self.tr('TUFLOW Manning Shapefile')))

    def processAlgorithm(self, parameters, context, feedback):
        aoi = self.parameterAsVectorLayer(parameters, self.AOI, context)
        year_index = int(self.parameterAsString(parameters, self.YEAR, context))
        year_string = self.YEARLIST[year_index]
        shp_proxy = (self.parameterAsString(parameters, self.OUTPUT_SHP, context) or '').strip()
        vec_dest = (self.parameterAsString(parameters, self.OUTPUT_VEC, context) or '').strip()

        make_tmf = self.parameterAsBool(parameters, self.MAKE_TMF, context)
        tmf_path = self.parameterAsFile(parameters, self.TMF_PATH, context)
        get_roads = self.parameterAsBool(parameters, self.GET_ROADS, context)
        get_water = self.parameterAsBool(parameters, self.GET_WATER, context)
        get_wetlands = self.parameterAsBool(parameters, self.GET_WETLANDS, context)
        get_streams = self.parameterAsBool(parameters, self.GET_STREAMS, context)
        get_sports = self.parameterAsBool(parameters, self.GET_SPORTS, context)

        # --- NEW: tri-state Buildings read (replaces old GET_BUILDINGS + BUILDINGS_SOURCE)
        bldg_mode = int(self.parameterAsEnum(parameters, self.BUILDINGS_MODE, context))
        get_buildings = (bldg_mode != 0)                      # None (0) vs any source (1/2)
        bldg_source_idx = (bldg_mode - 1) if bldg_mode > 0 else 0  # 0=OSM, 1=MS

        merge_additional = self.parameterAsBool(parameters, self.MERGE_ADDITIONAL, context)

        try: roads_buffer_m = float(self.parameterAsDouble(parameters, self.ROADS_BUFFER_M, context))
        except Exception: roads_buffer_m = 4.0
        try: streams_buffer_m = float(self.parameterAsDouble(parameters, self.STREAMS_BUFFER_M, context))
        except Exception: streams_buffer_m = 8.0

        if get_roads and (roads_buffer_m is None or roads_buffer_m <= 0):
            raise QgsProcessingException("Road buffer distance must be greater than 0 m when 'Get roads?' is enabled.")
        if get_streams and (streams_buffer_m is None or streams_buffer_m <= 0):
            raise QgsProcessingException("Streams buffer distance must be greater than 0 m when 'Get streams?' is enabled.")

        shp_path = shp_proxy or vec_dest
        if not shp_path:
            raise QgsProcessingException("Please provide an output shapefile path (Step 3) or a vector destination.")
        if shp_proxy and not shp_path.lower().endswith('.shp'):
            shp_path = shp_path + '.shp'
        out_folder = os.path.dirname(shp_path) or '.'
        os.makedirs(out_folder, exist_ok=True)

        aoi_src_crs = aoi.crs()
        plugin_dir = os.path.dirname(os.path.abspath(__file__))
        utm_filename = os.path.join(plugin_dir, 'resources', 'World_UTM_Grid.shp')
        utm_layer = QgsVectorLayer(utm_filename, 'World_UTM_Grid', 'ogr')
        qml_path_rel = os.path.join(plugin_dir, "resources", "tuflow_mannings.qml")

        try: processing.run("native:createspatialindex", {'INPUT': utm_layer}, context=context, feedback=feedback)
        except Exception: pass

        temp_dir = TemporaryDirectory(delete=True)
        scratch_folder = temp_dir.name
        _set_gdal_env(scratch_folder)

        model_crs = QgsCoordinateReferenceSystem('EPSG:3857')
        aoi_layer = processing.run("native:reprojectlayer",
                                   {'INPUT': aoi, 'TARGET_CRS': model_crs, 'OUTPUT': 'TEMPORARY_OUTPUT'},
                                   context=context, feedback=feedback)['OUTPUT']

        processing.run("native:selectbylocation",
                       {'INPUT': utm_layer, 'PREDICATE': [0], 'INTERSECT': aoi_layer, 'METHOD': 0},
                       context=context, feedback=feedback)
        sel_path = path.join(scratch_folder, 'selected_utm.shp')
        QgsVectorFileWriter.writeAsVectorFormat(utm_layer, sel_path, 'utf-8', driverName='ESRI Shapefile', onlySelected=True)
        temp_selection = QgsVectorLayer(sel_path, 'temp_selection', 'ogr')
        utm_zones = [[f[1], f[2]] for f in temp_selection.getFeatures()]

        lc_return = []
        for i in range(len(utm_zones)):
            if feedback.isCanceled(): break
            feedback.setProgressText(f'Downloading LULC Data {i+1}/{len(utm_zones)}...')
            temp_return = downloadLandCoverRaster(i, utm_zones, year_string, scratch_folder)
            lc_return.append(temp_return)

        temp_raster = path.join(scratch_folder, 'lc_clip.tif')
        mosaicAndClipRasters(lc_return, aoi_layer, scratch_folder, temp_raster)

        lc_raster = QgsRasterLayer(temp_raster, 'lc_clip')
        if not lc_raster or not lc_raster.isValid():
            raise QgsProcessingException('Failed to open the clipped land cover raster.')

        polys_all = processing.run('gdal:polygonize',
            {'INPUT': lc_raster,'BAND':1,'FIELD':'LC','EIGHT_CONNECTEDNESS':False,'EXTRA':'','OUTPUT':'TEMPORARY_OUTPUT'},
            context=context, feedback=feedback)['OUTPUT']

        allowed = [c for c,_ in self.CANONICAL_CLASSES]
        expr_keep = '"LC" IN ({})'.format(','.join(str(x) for x in allowed))
        filtered = processing.run('qgis:extractbyexpression',
            {'INPUT':polys_all,'EXPRESSION':expr_keep,'OUTPUT':'TEMPORARY_OUTPUT'},
            context=context, feedback=feedback)['OUTPUT']

        fl = QgsVectorLayer(filtered, 'filtered', 'ogr') if isinstance(filtered, str) else filtered
        present_codes = set()
        for f in fl.getFeatures():
            try: present_codes.add(int(f['LC']))
            except Exception: pass

        if get_water and 1 not in present_codes:
            present_codes.add(1)

        ordered_present = [code for code,_ in self.CANONICAL_CLASSES if code in present_codes]
        if not ordered_present:
            raise QgsProcessingException('No target land cover classes found in AOI.')

        id_map = {code: i+1 for i,code in enumerate(ordered_present)}
        desc_by_code = {code: desc for code,desc in self.CANONICAL_CLASSES}

        case_id = "CASE " + " ".join([f'WHEN "LC"={code} THEN {id_map[code]}' for code in ordered_present]) + " END"
        case_desc = "CASE " + " ".join([f'WHEN "LC"={code} THEN \'{desc_by_code[code]}\'' for code in ordered_present]) + " END"

        # ---------- ID sequence (Sports above Buildings and Roads) ----------
        # Order now: Wetland -> Streams -> Sports -> Buildings -> Roads
        current_max_id = max(id_map.values()) if id_map else 0
        wetland_id = (current_max_id + 1) if get_wetlands else None
        next_after_wetland = (wetland_id + 1) if wetland_id is not None else (current_max_id + 1)

        streams_id = next_after_wetland if get_streams else None
        next_after_streams = (streams_id + 1) if streams_id is not None else next_after_wetland

        sports_id = next_after_streams if get_sports else None
        next_after_sports = (sports_id + 1) if sports_id is not None else next_after_streams

        buildings_id = next_after_sports if get_buildings else None
        next_after_buildings = (buildings_id + 1) if buildings_id is not None else next_after_sports

        next_id_roads = next_after_buildings

        refactored = processing.run('native:refactorfields',
            {'INPUT':fl,'FIELDS_MAPPING':[{'name':'ID','type':2,'length':10,'precision':0,'expression':case_id},
                                          {'name':'Description','type':10,'length':50,'precision':0,'expression':case_desc}],
             'OUTPUT':'TEMPORARY_OUTPUT'}, context=context, feedback=feedback)['OUTPUT']

        reproj_final = processing.run('native:reprojectlayer',
            {'INPUT':refactored,'TARGET_CRS':aoi_src_crs,'OPERATION':'','OUTPUT':'TEMPORARY_OUTPUT'},
            context=context, feedback=feedback)['OUTPUT']

        main_for_save = reproj_final

        # ---------- TMF ----------
        id_code_desc = [(id_map[code], code, desc_by_code[code]) for code in ordered_present]
        id_code_desc.sort(key=lambda t: t[0])
        if any(code==10 for _,code,_ in id_code_desc):
            feedback.pushWarning("CHECK MATERIALS TO REMOVE CLOUDS")

        if make_tmf:
            header = ["!-----------------------!","! MATERIAL CONTROL FILE !","!-----------------------!",
                      "","!Format: Material ID, Manning's n, IL, CL, y1, n1, y2, n2",""]
            tmf_dir = os.path.dirname(tmf_path) or '.'
            os.makedirs(tmf_dir, exist_ok=True)
            try:
                if os.path.exists(tmf_path):
                    try: os.remove(tmf_path)
                    except Exception: os.replace(tmf_path, tmf_path + '.old')
                with open(tmf_path,'w',encoding='utf-8',newline='\n') as f:
                    for line in header: f.write(line+"\n")
                    # Base land cover classes
                    for new_id, code, desc in id_code_desc:
                        if code == 10:
                            f.write("CHECK MATERIALS TO REMOVE CLOUDS, , , , , , , , , ,  ! Clouds\n")
                            continue
                        nval = self.N_BY_CODE.get(code, 0.020)
                        last = self.LAST_BY_CODE.get(code, 1.0)
                        f.write(f"{new_id}, {nval:.3f}, , , , , , , -1, 0, {last:g} ! {desc}\n")
                    # Optional extras in requested order: Wetland, Streams, Sports, Buildings, Roads
                    if get_wetlands:
                        f.write(f"{wetland_id}, 0.090, , , , , , , -1, 0, 0 ! Wetland\n")
                    if get_streams:
                        f.write(f"{streams_id}, 0.035, , , , , , , -1, 0, 0 ! Watercourse / streams\n")
                    if get_sports:
                        f.write(f"{sports_id}, 0.030, , , , , , , -1, 0, 0 ! Sports field\n")
                    if get_buildings:
                        f.write(f"{buildings_id}, 0.500, , , , , , , -1, 0, 1 ! Building footprint\n")
                    f.write(f"{next_id_roads}, 0.015, , , , , , , -1, 0, 1 ! Paved surface\n")
                feedback.pushInfo(f"Saved TUFLOW .tmf: {tmf_path}")
            except Exception as ex:
                raise QgsProcessingException(f"Failed to write .tmf file: {tmf_path}\n{ex}")

        # -------------------- OSM Roads (GPKG-first) --------------------
        roads_final = None
        if get_roads:
            try:
                feedback.pushInfo("Fetching OSM roads within AOI extent…")
                south, west, north, east = _aoi_extent_wgs84(aoi)
                bbox = f"{south:.6f},{west:.6f},{north:.6f},{east:.6f}"
                overpass_query = f"""[out:xml][timeout:60];
(
  way({bbox})["highway"];
);
(._;>;);
out body;"""
                endpoints = [
                    "https://overpass-api.de/api/interpreter",
                    "https://overpass.kumi.systems/api/interpreter",
                    "https://overpass.osm.ch/api/interpreter",
                ]
                roads_osm = os.path.join(scratch_folder, f"roads_{_unique_suffix()}.osm")
                got = False; last_ex = None
                for ep in endpoints:
                    try:
                        enc = bytes(QUrl.toPercentEncoding(overpass_query)).decode("ascii")
                        url = QUrl(f"{ep}?data={enc}")
                        req = QNetworkRequest(url); req.setRawHeader(b'User-Agent', b'ManningsDownloader/1.0 (QGIS plugin)')
                        reply = QgsNetworkAccessManager.blockingGet(req)
                        if _write_valid_overpass_xml(reply.content(), roads_osm, feedback):
                            got = True; break
                        else:
                            raise IOError("Non-OSM or invalid XML returned.")
                    except Exception as ex:
                        last_ex = ex; feedback.pushWarning(f"Overpass failed on {ep}: {ex}")
                if not got: raise QgsProcessingException(f"All Overpass endpoints failed. Last error: {last_ex}")

                roads_gpkg = os.path.join(scratch_folder, f"roads_{_unique_suffix()}.gpkg")
                _package_osm_to_gpkg(roads_osm, roads_gpkg, ['lines','multilinestrings'], context, feedback)

                roads_lines  = QgsVectorLayer(f"{roads_gpkg}|layername=OSM_lines", 'OSM_lines', 'ogr')
                roads_mlines = QgsVectorLayer(f"{roads_gpkg}|layername=OSM_multilinestrings", 'OSM_multilines', 'ogr')

                to_merge = [vl for vl in (roads_lines, roads_mlines) if (vl and vl.isValid())]
                if not to_merge:
                    raise QgsProcessingException("GPKG has no readable roads sublayers.")
                merged = (processing.run('native:mergevectorlayers',
                           {'LAYERS': to_merge, 'CRS': QgsCoordinateReferenceSystem('EPSG:4326'), 'OUTPUT': 'TEMPORARY_OUTPUT'},
                           context=context, feedback=feedback)['OUTPUT']) if len(to_merge) > 1 else to_merge[0]

                merged_vl = QgsVectorLayer(merged, 'merged', 'ogr') if isinstance(merged, str) else merged
                field_names = [f.name() for f in merged_vl.fields()] if merged_vl and merged_vl.isValid() else []
                fields_set = set(n.lower() for n in field_names)

                allowed_hw = ['motorway','motorway_link','trunk','trunk_link','primary','primary_link',
                              'secondary','secondary_link','tertiary','tertiary_link','unclassified',
                              'residential','service','living_street']
                allowed_list = ','.join("'{}'".format(v) for v in allowed_hw)

                if 'highway' in fields_set:
                    conds = [f"array_contains(array({allowed_list}), lower(\"highway\"))"]
                    if 'access' in fields_set:         conds.append("(coalesce(lower(\"access\"), '') NOT IN ('no','private'))")
                    if 'motor_vehicle' in fields_set:  conds.append("(coalesce(lower(\"motor_vehicle\"), '') <> 'no')")
                    if 'motorcar' in fields_set:       conds.append("(coalesce(lower(\"motorcar\"), '') <> 'no')")
                    expr_car_roads = ' AND '.join(conds)
                else:
                    hw_expr = "lower(regexp_substr(\"other_tags\", '\"highway\"=>?\"([^\"]+)\"'))"
                    expr_car_roads = f"array_contains(array({allowed_list}), {hw_expr})"

                roads_all = processing.run('qgis:extractbyexpression',
                    {'INPUT': merged_vl, 'EXPRESSION': expr_car_roads, 'OUTPUT': 'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']

                buffer_crs = aoi_src_crs if not aoi_src_crs.isGeographic() else QgsCoordinateReferenceSystem('EPSG:3857')
                roads_proj = processing.run('native:reprojectlayer',
                    {'INPUT': roads_all, 'TARGET_CRS': buffer_crs, 'OUTPUT': 'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']
                aoi_proj = processing.run('native:reprojectlayer',
                    {'INPUT': aoi, 'TARGET_CRS': buffer_crs, 'OUTPUT': 'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']
                roads_clip = processing.run('native:clip',
                    {'INPUT': roads_proj, 'OVERLAY': aoi_proj, 'OUTPUT': 'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']

                roads_buf = processing.run('native:buffer',
                    {'INPUT': roads_clip,'DISTANCE': float(roads_buffer_m),'SEGMENTS':16,'END_CAP_STYLE':0,'JOIN_STYLE':0,
                     'MITER_LIMIT':2.0,'DISSOLVE':False,'OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']

                roads_refactored = processing.run('native:refactorfields',
                    {'INPUT': roads_buf,'FIELDS_MAPPING':[
                        {'name':'ID','type':2,'length':10,'precision':0,'expression':str(next_id_roads)},
                        {'name':'Description','type':10,'length':50,'precision':0,'expression':"'Paved surface'"}],
                     'OUTPUT':'TEMPORARY_OUTPUT'}, context=context, feedback=feedback)['OUTPUT']

                roads_final = processing.run('native:reprojectlayer',
                    {'INPUT': roads_refactored,'TARGET_CRS': aoi_src_crs,'OPERATION':'','OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']

                if merge_additional:
                    rf_vl = QgsVectorLayer(roads_final, 'roads_final', 'ogr') if isinstance(roads_final, str) else roads_final
                    if rf_vl and rf_vl.isValid() and _has_features(rf_vl):
                        main_for_save = processing.run('native:mergevectorlayers',
                            {'LAYERS':[main_for_save, roads_final],'CRS': aoi_src_crs,'OUTPUT':'TEMPORARY_OUTPUT'},
                            context=context, feedback=feedback)['OUTPUT']
                        feedback.pushInfo("Merged roads into main 2d_mat shapefile as 'Paved surface'.")
                else:
                    base, ext = os.path.splitext(shp_path)
                    dirn, stem = os.path.split(base)
                    roads_stem = f"{stem[:-2]}_Roads_R" if stem.endswith('_R') else (re.match(r'^(.*)_R$', stem).group(1) + "_Roads_R" if re.match(r'^(.*)_R$', stem) else f"{stem}_Roads")
                    roads_path = os.path.join(dirn, roads_stem + ext)
                    os.makedirs(os.path.dirname(roads_path) or '.', exist_ok=True)
                    _unload_layers_pointing_to(roads_path)
                    for extn in ('.shp','.dbf','.shx','.prj','.cpg','.qpj'):
                        fp = roads_path[:-4] + extn
                        if os.path.exists(fp):
                            try: os.remove(fp)
                            except Exception:
                                try: os.replace(fp, fp + '.old')
                                except Exception: pass
                    saved_roads = processing.run('native:savefeatures',
                        {'INPUT': roads_final,'OUTPUT': roads_path,'LAYER_OPTIONS':['ENCODING=UTF-8'],'DATASOURCE_OPTIONS':['ENCODING=UTF-8']},
                        context=context, feedback=feedback)['OUTPUT']
                    try:
                        with open(saved_roads[:-4] + '.cpg', 'w', encoding='ascii') as f: f.write('UTF-8')
                    except Exception: pass
                    try:
                        roads_vl = QgsVectorLayer(saved_roads, os.path.basename(saved_roads), 'ogr')
                        if roads_vl and roads_vl.isValid():
                            QgsProject.instance().addMapLayer(roads_vl)
                            _apply_qml_style(roads_vl, qml_path_rel, feedback)
                    except Exception: pass
                    feedback.pushInfo(f"Saved OSM Roads ({roads_buffer_m:.3f} m buffer): {saved_roads}")
            except Exception as ex:
                feedback.pushWarning(f"OSM roads step failed: {ex}")

        # -------------------- OSM Water (GPKG-first + fallback) --------------------
        water_final = None
        if get_water:
            try:
                feedback.pushInfo("Fetching OSM water bodies (STRICT natural=water)…")
                south, west, north, east = _aoi_extent_wgs84(aoi)
                bbox = f"{south:.6f},{west:.6f},{north:.6f},{east:.6f}"
                overpass_query = f"""[out:xml][timeout:60];
(
  way({bbox})["natural"="water"];
  relation({bbox})["natural"="water"];
);
(._;>;);
out body;"""
                endpoints = ["https://overpass-api.de/api/interpreter","https://overpass.kumi.systems/api/interpreter","https://overpass.osm.ch/api/interpreter"]
                water_osm = os.path.join(scratch_folder, f"water_{_unique_suffix()}.osm")
                got = False; last_ex = None
                for ep in endpoints:
                    try:
                        enc = bytes(QUrl.toPercentEncoding(overpass_query)).decode("ascii")
                        url = QUrl(f"{ep}?data={enc}")
                        req = QNetworkRequest(url); req.setRawHeader(b'User-Agent', b'ManningsDownloader/1.0 (QGIS plugin)')
                        reply = QgsNetworkAccessManager.blockingGet(req)
                        if _write_valid_overpass_xml(reply.content(), water_osm, feedback):
                            got = True; break
                        else:
                            raise IOError("Non-OSM or invalid XML returned.")
                    except Exception as ex:
                        last_ex = ex; feedback.pushWarning(f"Overpass (water) failed on {ep}: {ex}")
                if not got: raise QgsProcessingException(f"All Overpass endpoints failed (water). Last error: {last_ex}")

                water_gpkg = os.path.join(scratch_folder, f"water_{_unique_suffix()}.gpkg")
                _package_osm_to_gpkg(water_osm, water_gpkg, ['multipolygons','lines','multilinestrings'], context, feedback)

                water_mpolys = QgsVectorLayer(f"{water_gpkg}|layername=OSM_multipolygons", 'OSM_water_multipolygons', 'ogr')
                lines = QgsVectorLayer(f"{water_gpkg}|layername=OSM_lines", 'OSM_water_lines', 'ogr')
                mlines = QgsVectorLayer(f"{water_gpkg}|layername=OSM_multilinestrings", 'OSM_water_multilines', 'ogr')

                names_lower = [f.name().lower() for f in water_mpolys.fields()] if water_mpolys and water_mpolys.isValid() else []
                expr_water_only = "lower(\"natural\") = 'water'" if 'natural' in names_lower \
                    else "lower(regexp_substr(\"other_tags\", '\"natural\"=>?\"([^\"]+)\"')) = 'water'"

                water_source = None
                if water_mpolys and water_mpolys.isValid() and _has_features(water_mpolys):
                    water_source = processing.run('qgis:extractbyexpression',
                        {'INPUT': water_mpolys,'EXPRESSION': expr_water_only,'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                else:
                    feedback.pushInfo("Water multipolygons empty — rebuilding polygons from lines.")
                    candidates = [vl for vl in (lines, mlines) if (vl and vl.isValid())]
                    if not candidates:
                        raise QgsProcessingException("No water lines/multilines found in GPKG.")
                    merged = processing.run('native:mergevectorlayers',
                        {'LAYERS': candidates,'CRS': QgsCoordinateReferenceSystem('EPSG:4326'),'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    merged_vl = QgsVectorLayer(merged,'water_merged','ogr') if isinstance(merged,str) else merged
                    water_lines = processing.run('qgis:extractbyexpression',
                        {'INPUT': merged_vl,'EXPRESSION': expr_water_only,'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    fld_names = [f.name().lower() for f in QgsVectorLayer(water_lines,'tmp','ogr').fields()]
                    dissolve_field = 'osm_id' if 'osm_id' in fld_names else '@id' if '@id' in fld_names else None
                    water_diss = processing.run('native:dissolve',
                        {'INPUT': water_lines,'FIELD': dissolve_field or [],'SEPARATE_DISJOINT': False,'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    water_source = processing.run('native:polygonize',
                        {'INPUT': water_diss,'KEEP_FIELDS': [],'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    if not _has_features(QgsVectorLayer(water_source,'tmp','ogr')):
                        raise QgsProcessingException("No water polygons could be reconstructed from linework.")

                water_proj = processing.run('native:reprojectlayer',
                    {'INPUT': water_source,'TARGET_CRS': aoi_src_crs,'OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']
                water_clip = processing.run('native:clip',
                    {'INPUT': water_proj,'OVERLAY': aoi,'OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']
                water_clip_vl = QgsVectorLayer(water_clip,'water_clip','ogr') if isinstance(water_clip,str) else water_clip

                if not _has_features(water_clip_vl):
                    feedback.pushWarning("No STRICT natural=water polygons intersect the AOI after clip.")
                else:
                    water_refactored = processing.run('native:refactorfields',
                        {'INPUT': water_clip,'FIELDS_MAPPING':[
                            {'name':'ID','type':2,'length':10,'precision':0,'expression':'1'},
                            {'name':'Description','type':10,'length':50,'precision':0,'expression':"'Water'"}],
                         'OUTPUT':'TEMPORARY_OUTPUT'}, context=context, feedback=feedback)['OUTPUT']
                    water_final = water_refactored

                    if merge_additional:
                        wf_vl = QgsVectorLayer(water_final,'water_final','ogr') if isinstance(water_final,str) else water_final
                        if _has_features(wf_vl):
                            main_for_save = processing.run('native:mergevectorlayers',
                                {'LAYERS':[main_for_save, water_final],'CRS': aoi_src_crs,'OUTPUT':'TEMPORARY_OUTPUT'},
                                context=context, feedback=feedback)['OUTPUT']
                            feedback.pushInfo("Merged water (ID=1).")
                    else:
                        base, ext = os.path.splitext(shp_path); dirn, stem = os.path.split(base)
                        water_stem = f"{stem[:-2]}_Water_R" if stem.endswith('_R') else (re.match(r'^(.*)_R$', stem).group(1) + "_Water_R" if re.match(r'^(.*)_R$', stem) else f"{stem}_Water")
                        water_path = os.path.join(dirn, water_stem + ext)
                        os.makedirs(os.path.dirname(water_path) or '.', exist_ok=True)
                        _unload_layers_pointing_to(water_path)
                        for extn in ('.shp','.dbf','.shx','.prj','.cpg','.qpj'):
                            fp = water_path[:-4] + extn
                            if os.path.exists(fp):
                                try: os.remove(fp)
                                except Exception:
                                    try: os.replace(fp, fp + '.old')
                                    except Exception: pass
                        saved_water = processing.run('native:savefeatures',
                            {'INPUT': water_final,'OUTPUT': water_path,'LAYER_OPTIONS':['ENCODING=UTF-8'],'DATASOURCE_OPTIONS':['ENCODING=UTF-8']},
                            context=context, feedback=feedback)['OUTPUT']
                        try:
                            with open(saved_water[:-4] + '.cpg','w',encoding='ascii') as f: f.write('UTF-8')
                        except Exception: pass
                        try:
                            water_vl = QgsVectorLayer(saved_water, os.path.basename(saved_water), 'ogr')
                            if water_vl and water_vl.isValid():
                                QgsProject.instance().addMapLayer(water_vl)
                                _apply_qml_style(water_vl, qml_path_rel, feedback)
                        except Exception: pass
                        feedback.pushInfo(f"Saved OSM Water bodies (no buffer): {saved_water}")
            except Exception as ex:
                feedback.pushWarning(f"OSM water step failed: {ex}")

        # -------------------- OSM Wetlands (GPKG-first + fallback) --------------------
        wetlands_final = None
        if get_wetlands:
            try:
                feedback.pushInfo("Fetching OSM wetlands (STRICT natural=wetland)…")
                south, west, north, east = _aoi_extent_wgs84(aoi)
                bbox = f"{south:.6f},{west:.6f},{north:.6f},{east:.6f}"
                overpass_query = f"""[out:xml][timeout:60];
(
  way({bbox})["natural"="wetland"];
  relation({bbox})["natural"="wetland"];
);
(._;>;);
out body;"""
                endpoints = ["https://overpass-api.de/api/interpreter","https://overpass.kumi.systems/api/interpreter","https://overpass.osm.ch/api/interpreter"]
                wetlands_osm = os.path.join(scratch_folder, f"wetlands_{_unique_suffix()}.osm")
                got = False; last_ex = None
                for ep in endpoints:
                    try:
                        enc = bytes(QUrl.toPercentEncoding(overpass_query)).decode("ascii")
                        url = QUrl(f"{ep}?data={enc}")
                        req = QNetworkRequest(url); req.setRawHeader(b'User-Agent', b'ManningsDownloader/1.0 (QGIS plugin)')
                        reply = QgsNetworkAccessManager.blockingGet(req)
                        if _write_valid_overpass_xml(reply.content(), wetlands_osm, feedback):
                            got = True; break
                        else:
                            raise IOError("Non-OSM or invalid XML returned.")
                    except Exception as ex:
                        last_ex = ex; feedback.pushWarning(f"Overpass (wetlands) failed on {ep}: {ex}")
                if not got: raise QgsProcessingException(f"All Overpass endpoints failed (wetlands). Last error: {last_ex}")

                wetlands_gpkg = os.path.join(scratch_folder, f"wetlands_{_unique_suffix()}.gpkg")
                _package_osm_to_gpkg(wetlands_osm, wetlands_gpkg, ['multipolygons','lines','multilinestrings'], context, feedback)

                wetlands_mpolys = QgsVectorLayer(f"{wetlands_gpkg}|layername=OSM_multipolygons", 'OSM_wetlands_multipolygons', 'ogr')
                lines  = QgsVectorLayer(f"{wetlands_gpkg}|layername=OSM_lines", 'OSM_wetlands_lines', 'ogr')
                mlines = QgsVectorLayer(f"{wetlands_gpkg}|layername=OSM_multilinestrings", 'OSM_wetlands_multilines', 'ogr')

                names_lower = [f.name().lower() for f in wetlands_mpolys.fields()] if wetlands_mpolys and wetlands_mpolys.isValid() else []
                expr_wet_only = "lower(\"natural\") = 'wetland'" if 'natural' in names_lower \
                    else "lower(regexp_substr(\"other_tags\", '\"natural\"=>?\"([^\"]+)\"')) = 'wetland'"

                wetlands_source = None
                if wetlands_mpolys and wetlands_mpolys.isValid() and _has_features(wetlands_mpolys):
                    wetlands_source = processing.run('qgis:extractbyexpression',
                        {'INPUT': wetlands_mpolys,'EXPRESSION': expr_wet_only,'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                else:
                    feedback.pushInfo("Wetlands multipolygons empty — rebuilding polygons from lines.")
                    candidates = [vl for vl in (lines, mlines) if (vl and vl.isValid())]
                    if not candidates:
                        raise QgsProcessingException("No wetlands lines/multilines found in GPKG.")
                    merged = processing.run('native:mergevectorlayers',
                        {'LAYERS': candidates,'CRS': QgsCoordinateReferenceSystem('EPSG:4326'),'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    merged_vl = QgsVectorLayer(merged,'wetlands_merged','ogr') if isinstance(merged,str) else merged
                    wet_lines = processing.run('qgis:extractbyexpression',
                        {'INPUT': merged_vl,'EXPRESSION': expr_wet_only,'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    fld_names = [f.name().lower() for f in QgsVectorLayer(wet_lines,'tmp','ogr').fields()]
                    dissolve_field = 'osm_id' if 'osm_id' in fld_names else '@id' if '@id' in fld_names else None
                    wet_diss = processing.run('native:dissolve',
                        {'INPUT': wet_lines,'FIELD': dissolve_field or [],'SEPARATE_DISJOINT': False,'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    wetlands_source = processing.run('native:polygonize',
                        {'INPUT': wet_diss,'KEEP_FIELDS': [],'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    if not _has_features(QgsVectorLayer(wetlands_source,'tmp','ogr')):
                        raise QgsProcessingException("No wetlands polygons could be reconstructed from linework.")

                wetlands_proj = processing.run('native:reprojectlayer',
                    {'INPUT': wetlands_source,'TARGET_CRS': aoi_src_crs,'OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']
                wetlands_clip = processing.run('native:clip',
                    {'INPUT': wetlands_proj,'OVERLAY': aoi,'OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']
                wetlands_clip_vl = QgsVectorLayer(wetlands_clip,'wetlands_clip','ogr') if isinstance(wetlands_clip,str) else wetlands_clip

                if not _has_features(wetlands_clip_vl):
                    feedback.pushWarning("No STRICT natural=wetland polygons intersect the AOI after clip.")
                else:
                    wetlands_refactored = processing.run('native:refactorfields',
                        {'INPUT': wetlands_clip,'FIELDS_MAPPING':[
                            {'name':'ID','type':2,'length':10,'precision':0,'expression':str(wetland_id)},
                            {'name':'Description','type':10,'length':50,'precision':0,'expression':"'Wetland'"}],
                         'OUTPUT':'TEMPORARY_OUTPUT'}, context=context, feedback=feedback)['OUTPUT']
                    wetlands_final = wetlands_refactored

                    if merge_additional:
                        wl_vl = QgsVectorLayer(wetlands_final,'wetlands_final','ogr') if isinstance(wetlands_final,str) else wetlands_final
                        if _has_features(wl_vl):
                            main_for_save = processing.run('native:mergevectorlayers',
                                {'LAYERS':[main_for_save, wetlands_final],'CRS': aoi_src_crs,'OUTPUT':'TEMPORARY_OUTPUT'},
                                context=context, feedback=feedback)['OUTPUT']
                            feedback.pushInfo(f"Merged wetlands (ID={wetland_id}).")
                    else:
                        base, ext = os.path.splitext(shp_path); dirn, stem = os.path.split(base)
                        wet_stem = f"{stem[:-2]}_Wetland_R" if stem.endswith('_R') else (re.match(r'^(.*)_R$', stem).group(1) + "_Wetland_R" if re.match(r'^(.*)_R$', stem) else f"{stem}_Wetland")
                        wet_path = os.path.join(dirn, wet_stem + ext)
                        os.makedirs(os.path.dirname(wet_path) or '.', exist_ok=True)
                        _unload_layers_pointing_to(wet_path)
                        for extn in ('.shp','.dbf','.shx','.prj','.cpg','.qpj'):
                            fp = wet_path[:-4] + extn
                            if os.path.exists(fp):
                                try: os.remove(fp)
                                except Exception:
                                    try: os.replace(fp, fp + '.old')
                                    except Exception: pass
                        saved_wet = processing.run('native:savefeatures',
                            {'INPUT': wetlands_final,'OUTPUT': wet_path,'LAYER_OPTIONS':['ENCODING=UTF-8'],'DATASOURCE_OPTIONS':['ENCODING=UTF-8']},
                            context=context, feedback=feedback)['OUTPUT']
                        try:
                            with open(saved_wet[:-4] + '.cpg','w',encoding='ascii') as f: f.write('UTF-8')
                        except Exception: pass
                        try:
                            wet_vl = QgsVectorLayer(saved_wet, os.path.basename(saved_wet), 'ogr')
                            if wet_vl and wet_vl.isValid():
                                QgsProject.instance().addMapLayer(wet_vl)
                                _apply_qml_style(wet_vl, qml_path_rel, feedback)
                        except Exception: pass
                        feedback.pushInfo(f"Saved OSM Wetlands (no buffer): {saved_wet}")
            except Exception as ex:
                feedback.pushWarning(f"OSM wetlands step failed: {ex}")

        # -------------------- OSM Streams (GPKG-first) --------------------
        streams_final = None
        if get_streams:
            try:
                feedback.pushInfo("Fetching OSM streams (river/stream)…")
                south, west, north, east = _aoi_extent_wgs84(aoi)
                bbox = f"{south:.6f},{west:.6f},{north:.6f},{east:.6f}"
                overpass_query = f"""[out:xml][timeout:60];
(
  way({bbox})["waterway"="river"];
  relation({bbox})["waterway"="river"];
  way({bbox})["waterway"="stream"];
  relation({bbox})["waterway"="stream"];
);
(._;>;);
out body;"""
                endpoints = ["https://overpass-api.de/api/interpreter","https://overpass.kumi.systems/api/interpreter","https://overpass.osm.ch/api/interpreter"]
                streams_osm = os.path.join(scratch_folder, f"streams_{_unique_suffix()}.osm")
                got = False; last_ex = None
                for ep in endpoints:
                    try:
                        enc = bytes(QUrl.toPercentEncoding(overpass_query)).decode("ascii")
                        url = QUrl(f"{ep}?data={enc}")
                        req = QNetworkRequest(url); req.setRawHeader(b'User-Agent', b'ManningsDownloader/1.0 (QGIS plugin)')
                        reply = QgsNetworkAccessManager.blockingGet(req)
                        if _write_valid_overpass_xml(reply.content(), streams_osm, feedback):
                            got = True; break
                        else:
                            raise IOError("Non-OSM or invalid XML returned.")
                    except Exception as ex:
                        last_ex = ex; feedback.pushWarning(f"Overpass (streams) failed on {ep}: {ex}")
                if not got: raise QgsProcessingException(f"All Overpass endpoints failed (streams). Last error: {last_ex}")

                streams_gpkg = os.path.join(scratch_folder, f"streams_{_unique_suffix()}.gpkg")
                _package_osm_to_gpkg(streams_osm, streams_gpkg, ['lines','multilinestrings'], context, feedback)

                streams_lines  = QgsVectorLayer(f"{streams_gpkg}|layername=OSM_lines", 'OSM_streams_lines', 'ogr')
                streams_mlines = QgsVectorLayer(f"{streams_gpkg}|layername=OSM_multilinestrings", 'OSM_streams_multilines', 'ogr')

                to_merge = [vl for vl in (streams_lines, streams_mlines) if (vl and vl.isValid())]
                if not to_merge:
                    raise QgsProcessingException("GeoPackage has no readable streams sublayers.")
                streams_merged = (processing.run('native:mergevectorlayers',
                                    {'LAYERS': to_merge,'CRS': QgsCoordinateReferenceSystem('EPSG:4326'),'OUTPUT':'TEMPORARY_OUTPUT'},
                                    context=context, feedback=feedback)['OUTPUT']) if len(to_merge) > 1 else to_merge[0]

                merged_vl = QgsVectorLayer(streams_merged,'streams_merged','ogr') if isinstance(streams_merged,str) else streams_merged
                field_names = [f.name() for f in merged_vl.fields()] if merged_vl and merged_vl.isValid() else []
                names_lower = [n.lower() for n in field_names]
                expr_streams = "lower(\"waterway\") IN ('river','stream')" if 'waterway' in names_lower \
                    else "lower(regexp_substr(\"other_tags\", '\"waterway\"=>?\"([^\"]+)\"')) IN ('river','stream')"

                streams_all = processing.run('qgis:extractbyexpression',
                    {'INPUT': merged_vl,'EXPRESSION': expr_streams,'OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']

                buffer_crs = aoi_src_crs if not aoi_src_crs.isGeographic() else QgsCoordinateReferenceSystem('EPSG:3857')
                streams_proj = processing.run('native:reprojectlayer',
                    {'INPUT': streams_all,'TARGET_CRS': buffer_crs,'OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']
                aoi_proj_for_streams = processing.run('native:reprojectlayer',
                    {'INPUT': aoi,'TARGET_CRS': buffer_crs,'OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']

                streams_clip = processing.run('native:clip',
                    {'INPUT': streams_proj,'OVERLAY': aoi_proj_for_streams,'OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']

                streams_buf = processing.run('native:buffer',
                    {'INPUT': streams_clip,'DISTANCE': float(streams_buffer_m),'SEGMENTS':16,'END_CAP_STYLE':0,'JOIN_STYLE':0,
                     'MITER_LIMIT':2.0,'DISSOLVE':False,'OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']

                streams_after_diff = streams_buf
                if get_water and water_final:
                    try:
                        w_vl = QgsVectorLayer(water_final,'water_final','ogr') if isinstance(water_final,str) else water_final
                        if _has_features(w_vl):
                            water_for_diff = processing.run('native:reprojectlayer',
                                {'INPUT': water_final,'TARGET_CRS': buffer_crs,'OUTPUT':'TEMPORARY_OUTPUT'},
                                context=context, feedback=feedback)['OUTPUT']
                            streams_after_diff = processing.run('native:difference',
                                {'INPUT': streams_buf,'OVERLAY': water_for_diff,'OUTPUT':'TEMPORARY_OUTPUT'},
                                context=context, feedback=feedback)['OUTPUT']
                            feedback.pushInfo("Trimmed streams outside water polygons.")
                    except Exception as ex:
                        feedback.pushWarning(f"Stream trimming failed (continuing): {ex}")

                streams_refactored = processing.run('native:refactorfields',
                    {'INPUT': streams_after_diff,'FIELDS_MAPPING':[
                        {'name':'ID','type':2,'length':10,'precision':0,'expression':str(streams_id)},
                        {'name':'Description','type':10,'length':50,'precision':0,'expression':"'Watercourse / streams'"}],
                     'OUTPUT':'TEMPORARY_OUTPUT'}, context=context, feedback=feedback)['OUTPUT']

                streams_final = processing.run('native:reprojectlayer',
                    {'INPUT': streams_refactored,'TARGET_CRS': aoi_src_crs,'OPERATION':'','OUTPUT':'TEMPORARY_OUTPUT'},
                    context=context, feedback=feedback)['OUTPUT']

                if merge_additional:
                    sf_vl = QgsVectorLayer(streams_final,'streams_final','ogr') if isinstance(streams_final,str) else streams_final
                    if sf_vl and sf_vl.isValid() and _has_features(sf_vl):
                        main_for_save = processing.run('native:mergevectorlayers',
                            {'LAYERS':[main_for_save, streams_final],'CRS': aoi_src_crs,'OUTPUT':'TEMPORARY_OUTPUT'},
                            context=context, feedback=feedback)['OUTPUT']
                        feedback.pushInfo(f"Merged streams (ID={streams_id}).")
                else:
                    base, ext = os.path.splitext(shp_path); dirn, stem = os.path.split(base)
                    streams_stem = f"{stem[:-2]}_Streams_R" if stem.endswith('_R') else (re.match(r'^(.*)_R$', stem).group(1) + "_Streams_R" if re.match(r'^(.*)_R$', stem) else f"{stem}_Streams")
                    streams_path = os.path.join(dirn, streams_stem + ext)
                    os.makedirs(os.path.dirname(streams_path) or '.', exist_ok=True)
                    _unload_layers_pointing_to(streams_path)
                    for extn in ('.shp','.dbf','.shx','.prj','.cpg','.qpj'):
                        fp = streams_path[:-4] + extn
                        if os.path.exists(fp):
                            try: os.remove(fp)
                            except Exception:
                                try: os.replace(fp, fp + '.old')
                                except Exception: pass
                    saved_streams = processing.run('native:savefeatures',
                        {'INPUT': streams_final,'OUTPUT': streams_path,'LAYER_OPTIONS':['ENCODING=UTF-8'],'DATASOURCE_OPTIONS':['ENCODING=UTF-8']},
                        context=context, feedback=feedback)['OUTPUT']
                    try:
                        with open(saved_streams[:-4] + '.cpg','w',encoding='ascii') as f: f.write('UTF-8')
                    except Exception: pass
                    try:
                        streams_vl = QgsVectorLayer(saved_streams, os.path.basename(saved_streams), 'ogr')
                        if streams_vl and streams_vl.isValid():
                            QgsProject.instance().addMapLayer(streams_vl)
                            _apply_qml_style(streams_vl, qml_path_rel, feedback)
                    except Exception: pass
                    feedback.pushInfo(f"Saved OSM Streams ({streams_buffer_m:.3f} m buffer): {saved_streams}")
            except Exception as ex:
                feedback.pushWarning(f"OSM streams step failed: {ex}")

        # -------------------- Buildings (OSM or Microsoft) --------------------
        buildings_final = None
        if get_buildings:
            try:
                if bldg_source_idx == 0:
                    # -------------------- OSM branch --------------------
                    feedback.pushInfo("Fetching OSM buildings (building=*)…")
                    south, west, north, east = _aoi_extent_wgs84(aoi)
                    bbox = f"{south:.6f},{west:.6f},{north:.6f},{east:.6f}"
                    overpass_query = f"""[out:xml][timeout:60];
(
  way({bbox})["building"];
  relation({bbox})["building"];
);
(._;>;);
out body;"""
                    endpoints = ["https://overpass-api.de/api/interpreter","https://overpass.kumi.systems/api/interpreter","https://overpass.osm.ch/api/interpreter"]
                    buildings_osm = os.path.join(scratch_folder, f"buildings_{_unique_suffix()}.osm")
                    got = False; last_ex = None
                    for ep in endpoints:
                        try:
                            enc = bytes(QUrl.toPercentEncoding(overpass_query)).decode("ascii")
                            url = QUrl(f"{ep}?data={enc}")
                            req = QNetworkRequest(url); req.setRawHeader(b'User-Agent', b'ManningsDownloader/1.0 (QGIS plugin)')
                            reply = QgsNetworkAccessManager.blockingGet(req)
                            if _write_valid_overpass_xml(reply.content(), buildings_osm, feedback):
                                got = True; break
                            else:
                                raise IOError("Non-OSM or invalid XML returned.")
                        except Exception as ex:
                            last_ex = ex; feedback.pushWarning(f"Overpass (buildings) failed on {ep}: {ex}")
                    if not got: raise QgsProcessingException(f"All Overpass endpoints failed (buildings). Last error: {last_ex}")

                    buildings_gpkg = os.path.join(scratch_folder, f"buildings_{_unique_suffix()}.gpkg")
                    _package_osm_to_gpkg(buildings_osm, buildings_gpkg, ['multipolygons','lines','multilinestrings'], context, feedback)

                    bldg_mpolys = QgsVectorLayer(f"{buildings_gpkg}|layername=OSM_multipolygons", 'OSM_buildings_multipolygons', 'ogr')
                    lines  = QgsVectorLayer(f"{buildings_gpkg}|layername=OSM_lines", 'OSM_buildings_lines', 'ogr')
                    mlines = QgsVectorLayer(f"{buildings_gpkg}|layername=OSM_multilinestrings", 'OSM_buildings_multilines', 'ogr')

                    def _bldg_filter_expression(vl):
                        names_lower = [f.name().lower() for f in vl.fields()]
                        return ("coalesce(trim(\"building\"),'') <> ''" if 'building' in names_lower
                                else "coalesce(trim(regexp_substr(\"other_tags\", '\"building\"=>?\"([^\"]+)\"')),'') <> ''")

                    bldg_source = None
                    if bldg_mpolys and bldg_mpolys.isValid() and _has_features(bldg_mpolys):
                        bldg_source = processing.run('qgis:extractbyexpression',
                            {'INPUT': bldg_mpolys,'EXPRESSION': _bldg_filter_expression(bldg_mpolys),'OUTPUT':'TEMPORARY_OUTPUT'},
                            context=context, feedback=feedback)['OUTPUT']
                    else:
                        feedback.pushInfo("Building multipolygons empty — rebuilding polygons from lines.")
                        candidates = [vl for vl in (lines, mlines) if (vl and vl.isValid())]
                        if not candidates:
                            raise QgsProcessingException("No building lines/multilines found in GPKG.")
                        merged = processing.run('native:mergevectorlayers',
                            {'LAYERS': candidates,'CRS': QgsCoordinateReferenceSystem('EPSG:4326'),'OUTPUT':'TEMPORARY_OUTPUT'},
                            context=context, feedback=feedback)['OUTPUT']
                        merged_vl = QgsVectorLayer(merged,'buildings_merged','ogr') if isinstance(merged,str) else merged
                        bldg_lines = processing.run('qgis:extractbyexpression',
                            {'INPUT': merged_vl,'EXPRESSION': _bldg_filter_expression(merged_vl),'OUTPUT':'TEMPORARY_OUTPUT'},
                            context=context, feedback=feedback)['OUTPUT']
                        fld_names = [f.name().lower() for f in QgsVectorLayer(bldg_lines,'tmp','ogr').fields()]
                        dissolve_field = 'osm_id' if 'osm_id' in fld_names else '@id' if '@id' in fld_names else None
                        bldg_diss = processing.run('native:dissolve',
                            {'INPUT': bldg_lines,'FIELD': dissolve_field or [],'SEPARATE_DISJOINT': False,'OUTPUT':'TEMPORARY_OUTPUT'},
                            context=context, feedback=feedback)['OUTPUT']
                        bldg_source = processing.run('native:polygonize',
                            {'INPUT': bldg_diss,'KEEP_FIELDS': [],'OUTPUT':'TEMPORARY_OUTPUT'},
                            context=context, feedback=feedback)['OUTPUT']
                        if not _has_features(QgsVectorLayer(bldg_source,'tmp','ogr')):
                            raise QgsProcessingException("No building polygons could be reconstructed from linework.")

                    bldg_proj = processing.run('native:reprojectlayer',
                        {'INPUT': bldg_source,'TARGET_CRS': aoi_src_crs,'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    bldg_clip = processing.run('native:clip',
                        {'INPUT': bldg_proj,'OVERLAY': aoi,'OUTPUT':'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    bldg_refactored = processing.run('native:refactorfields',
                        {'INPUT': bldg_clip,'FIELDS_MAPPING':[
                            {'name':'ID','type':2,'length':10,'precision':0,'expression':str(buildings_id)},
                            {'name':'Description','type':10,'length':50,'precision':0,'expression':"'Building footprint'"}],
                         'OUTPUT':'TEMPORARY_OUTPUT'}, context=context, feedback=feedback)['OUTPUT']
                    buildings_final = bldg_refactored

                else:
                    # -------------------- Microsoft (Planetary Computer) branch --------------------
                    feedback.pushInfo("Fetching Microsoft Building Footprints via Planetary Computer…")
                    ms_gpkg, ms_layername = _ms_buildings_to_gpkg(aoi, aoi_src_crs, scratch_folder, feedback)

                    ms_layer = QgsVectorLayer(f"{ms_gpkg}|layername={ms_layername}", "MS_buildings_raw", "ogr")
                    if not ms_layer or not ms_layer.isValid():
                        raise QgsProcessingException("Failed to load MS Buildings layer from GeoPackage.")

                    bldg_proj = processing.run('native:reprojectlayer',
                        {'INPUT': ms_layer, 'TARGET_CRS': aoi_src_crs, 'OUTPUT': 'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    bldg_clip = processing.run('native:clip',
                        {'INPUT': bldg_proj, 'OVERLAY': aoi, 'OUTPUT': 'TEMPORARY_OUTPUT'},
                        context=context, feedback=feedback)['OUTPUT']
                    bldg_refactored = processing.run('native:refactorfields',
                        {'INPUT': bldg_clip,'FIELDS_MAPPING':[
                            {'name':'ID','type':2,'length':10,'precision':0,'expression':str(buildings_id)},
                            {'name':'Description','type':10,'length':50,'precision':0,'expression':"'Building footprint'"}],
                         'OUTPUT':'TEMPORARY_OUTPUT'}, context=context, feedback=feedback)['OUTPUT']
                    buildings_final = bldg_refactored

                # ---- Merge or save buildings (shared) ----
                if buildings_final:
                    if merge_additional:
                        bf_vl = QgsVectorLayer(buildings_final,'buildings_final','ogr') if isinstance(buildings_final,str) else buildings_final
                        if bf_vl and bf_vl.isValid() and _has_features(bf_vl):
                            main_for_save = processing.run('native:mergevectorlayers',
                                {'LAYERS':[main_for_save, buildings_final],'CRS': aoi_src_crs,'OUTPUT':'TEMPORARY_OUTPUT'},
                                context=context, feedback=feedback)['OUTPUT']
                            feedback.pushInfo(f"Merged buildings (ID={buildings_id}).")
                    else:
                        base, ext = os.path.splitext(shp_path); dirn, stem = os.path.split(base)
                        bldg_stem = f"{stem[:-2]}_Buildings_R" if stem.endswith('_R') else (re.match(r'^(.*)_R$', stem).group(1) + "_Buildings_R" if re.match(r'^(.*)_R$', stem) else f"{stem}_Buildings")
                        bldg_path = os.path.join(dirn, bldg_stem + ext)
                        os.makedirs(os.path.dirname(bldg_path) or '.', exist_ok=True)
                        _unload_layers_pointing_to(bldg_path)
                        for extn in ('.shp','.dbf','.shx','.prj','.cpg','.qpj'):
                            fp = bldg_path[:-4] + extn
                            if os.path.exists(fp):
                                try: os.remove(fp)
                                except Exception:
                                    try: os.replace(fp, fp + '.old')
                                    except Exception: pass
                        saved_bldg = processing.run('native:savefeatures',
                            {'INPUT': buildings_final,'OUTPUT': bldg_path,'LAYER_OPTIONS':['ENCODING=UTF-8'],'DATASOURCE_OPTIONS':['ENCODING=UTF-8']},
                            context=context, feedback=feedback)['OUTPUT']
                        try:
                            with open(saved_bldg[:-4] + '.cpg','w',encoding='ascii') as f: f.write('UTF-8')
                        except Exception: pass
                        try:
                            bldg_vl = QgsVectorLayer(saved_bldg, os.path.basename(saved_bldg), 'ogr')
                            if bldg_vl and bldg_vl.isValid():
                                QgsProject.instance().addMapLayer(bldg_vl)
                                _apply_qml_style(bldg_vl, qml_path_rel, feedback)
                        except Exception: pass
                        feedback.pushInfo(f"Saved {'MS' if bldg_source_idx==1 else 'OSM'} Buildings (no buffer): {saved_bldg}")

            except Exception as ex:
                feedback.pushWarning(f"Buildings step failed ({'MS' if bldg_source_idx==1 else 'OSM'}): {ex}")

        # ---- Save main output ----
        if shp_path.lower().endswith('.shp'):
            _unload_layers_pointing_to(shp_path)
            for ext in ('.shp','.dbf','.shx','.prj','.cpg','.qpj'):
                fp = shp_path[:-4] + ext
                if os.path.exists(fp):
                    try: os.remove(fp)
                    except Exception as ex:
                        try: os.replace(fp, fp + '.old')
                        except Exception:
                            raise QgsProcessingException(
                                f"Unable to overwrite existing file component: {fp}\nClose any layers referencing it and try again.\n{ex}"
                            )

        saved_path = processing.run('native:savefeatures',
            {'INPUT': main_for_save, 'OUTPUT': shp_path, 'LAYER_OPTIONS':['ENCODING=UTF-8'], 'DATASOURCE_OPTIONS':['ENCODING=UTF-8']},
            context=context, feedback=feedback)['OUTPUT']

        if saved_path.lower().endswith('.shp'):
            try:
                with open(saved_path[:-4] + '.cpg','w',encoding='ascii') as f: f.write('UTF-8')
            except Exception: pass

        try:
            vlayer = QgsVectorLayer(saved_path, path.basename(saved_path), 'ogr')
            if vlayer and vlayer.isValid():
                QgsProject.instance().addMapLayer(vlayer)
                _apply_qml_style(vlayer, qml_path_rel, feedback)
        except Exception: pass

        feedback.setProgressText('...Complete!')
        return {self.OUTPUT: saved_path}

    def name(self):
        return 'Create Manning\'s Roughness from Area Of Interest'
    def displayName(self):
        return self.tr('Create Manning\'s Roughness from Area Of Interest')
    def tr(self, string):
        return QCoreApplication.translate('Processing', string)
    def createInstance(self):
        return DownloadFromAoi()
    def icon(self):
        return QIcon(path.dirname(__file__) + "/resources/aoi_icon_svg.svg")
    def shortHelpString(self):
        return """
        Downloads Sentinel-2 land cover data from Esri's Living Atlas based on user input area of interest (AOI).

        • 'Input AOI' is a vector polygon file (can contain multiple features).

        • 'Data Collection Year' is the year the Sentinel-2 (satellite land classification) data was sourced.

        • Output shapefile: type full path (e.g. ...\\2d_mat_NAME_R.shp).

        • Optional .tmf generation.

        ------------------------------------------
        ADDITIONAL FEATURES [Optional]:

        • 5) Get roads from OSM for a buffered polygons layer.

        • 6) Get water bodies from OSM (includes large watercourses).

        • 7) Get wetlands from OSM.

        • 8) Get streams from OSM for a buffered polygons layer. Recommended to also run (6) which captures the extent of larger watercourses better.

        • 9) Get sports fields from OSM (flat grass). Provides further refinement from Sentinel classification.

        • 10) Get buildings?: None / OSM (Overpass) / Microsoft (MS Building Footprints via Planetary Computer, ODbL). OSM buildings are hand-drawn and quite accurate but coverage is limited. Recommended to use OSM where available.
            Microsoft buildings requires extra packages in the QGIS Python env (open OsGeo4W Shell and install):
      pip install planetary-computer pystac-client deltalake==0.17.2 geopandas shapely mercantile adlfs fsspec pyarrow


        • 11) All selected additional features will be merged into the output shapefile path. Alternatively, additional features will be saved as 2d_mat_NAME_ADDITIONALFEATURE_R.shp.
                
        ------------------------------------------
        Contact Hugo O'Brien for help.
        """