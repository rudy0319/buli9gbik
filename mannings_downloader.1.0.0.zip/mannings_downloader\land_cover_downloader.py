# -*- coding: utf-8 -*-

"""
/***************************************************************************
 ManningsDownloader
                                 A QGIS plugin
 Downloads Sentinel-2 Land Cover Data from Esri's Living Atlas
 and creates a Manning's Roughness shapefile from it.
                              -------------------
        begin                : 2026-01-22
        email                : hugo.obrien@slrconsulting.com
 ***************************************************************************/

"""

__author__ = 'Hugo OBrien'
__date__ = '2026-01-22'
__revision__ = '$Format:%H$'

import os
import sys
import inspect

from qgis.core import QgsProcessingAlgorithm, QgsApplication
from .mannings_downloader_provider import ManningsDownloaderProvider

cmd_folder = os.path.split(inspect.getfile(inspect.currentframe()))[0]

if cmd_folder not in sys.path:
    sys.path.insert(0, cmd_folder)


class LandCoverDownloaderPlugin(object):

    def __init__(self):
        self.provider = None

    def initProcessing(self):
        """Init Processing provider for QGIS >= 3.8."""
        self.provider = ManningsDownloaderProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()

    def unload(self):
        QgsApplication.processingRegistry().removeProvider(self.provider)
