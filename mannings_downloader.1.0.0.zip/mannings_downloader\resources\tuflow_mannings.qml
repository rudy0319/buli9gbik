
<qgis version="3.34" styleCategories="Symbology|Labeling">
  <renderer-v2 type="RuleRenderer" symbollevels="0" forceraster="0" enableorderby="0">
    <rules key="root">
      <rule filter="&quot;Descriptio&quot; = 'Water'" label="Water" key="water" symbol="0"/>
      <rule filter="&quot;Descriptio&quot; = 'Trees'" label="Trees" key="trees" symbol="1"/>
      <rule filter="&quot;Descriptio&quot; = 'Flooded vegetation'" label="Flooded vegetation" key="floodedveg" symbol="2"/>
      <rule filter="&quot;Descriptio&quot; = 'Crops'" label="Crops" key="crops" symbol="3"/>
      <rule filter="&quot;Descriptio&quot; = 'Built area'" label="Built area" key="built" symbol="4"/>
      <rule filter="&quot;Descriptio&quot; = 'Bare ground'" label="Bare ground" key="bare" symbol="5"/>
      <rule filter="&quot;Descriptio&quot; = 'Snow/ice'" label="Snow/ice" key="snow" symbol="6"/>
      <rule filter="&quot;Descriptio&quot; = 'Clouds'" label="Clouds" key="clouds" symbol="7"/>
      <rule filter="&quot;Descriptio&quot; = 'Rangeland'" label="Rangeland" key="rangeland" symbol="8"/>
      <rule filter="&quot;Descriptio&quot; = 'Paved surface'" label="Paved surface" key="paved" symbol="9"/>
      <rule filter="&quot;Descriptio&quot; = 'Wetland'" label="Wetland" key="wetland" symbol="10"/>
      <rule filter="&quot;Descriptio&quot; = 'Watercourse / streams'" label="Watercourse / streams" key="watercourse" symbol="11"/>
      <rule filter="&quot;Descriptio&quot; = 'Sports field'" label="Sports field" key="sportsfield" symbol="12"/>
      <rule filter="&quot;Descriptio&quot; = 'Building footprint'" label="Building footprint" key="buildings" symbol="13"/>
    </rules>

    <symbols>
      <!-- 0: Water -->
      <symbol type="fill" name="0" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="0,70,255,150"/>
          <prop k="outline_color" v="10,70,120,180"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 1: Trees -->
      <symbol type="fill" name="1" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="34,139,34,150"/>
          <prop k="outline_color" v="20,80,20,180"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 2: Flooded vegetation -->
      <symbol type="fill" name="2" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="0,153,153,150"/>
          <prop k="outline_color" v="0,100,100,180"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 3: Crops -->
      <symbol type="fill" name="3" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="173,255,47,150"/>
          <prop k="outline_color" v="90,150,25,180"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 4: Built area (SOFT PINK) -->
      <symbol type="fill" name="4" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="255,182,193,150"/> <!-- Soft Pink -->
          <prop k="outline_color" v="200,140,150,180"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 5: Bare ground -->
      <symbol type="fill" name="5" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="205,133,63,150"/>
          <prop k="outline_color" v="120,80,40,180"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 6: Snow/ice -->
      <symbol type="fill" name="6" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="255,255,255,150"/>
          <prop k="outline_color" v="200,200,200,180"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 7: Clouds (BRIGHT RED) -->
      <symbol type="fill" name="7" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="255,0,0,150"/>     <!-- Bright red -->
          <prop k="outline_color" v="180,0,0,200"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 8: Rangeland -->
      <symbol type="fill" name="8" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="189,183,107,150"/>
          <prop k="outline_color" v="120,110,50,180"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 9: Paved surface -->
      <symbol type="fill" name="9" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="40,40,40,170"/>
          <prop k="outline_color" v="20,20,20,200"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 10: Wetland -->
      <symbol type="fill" name="10" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="110,80,40,180"/>
          <prop k="outline_color" v="70,45,25,220"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 11: Watercourse / streams -->
      <symbol type="fill" name="11" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="0,255,255,150"/>
          <prop k="outline_color" v="40,110,110,220"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 12: Sports field -->
      <symbol type="fill" name="12" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="160,0,255,170"/>
          <prop k="outline_color" v="20,20,20,200"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

      <!-- 13: Building footprint -->
      <symbol type="fill" name="13" alpha="1">
        <layer class="SimpleFill" locked="0" pass="0">
          <prop k="color" v="255,130,00,170"/>
          <prop k="outline_color" v="20,20,20,200"/>
          <prop k="outline_width" v="0.3"/>
          <prop k="style" v="solid"/>
        </layer>
      </symbol>

    </symbols>
  </renderer-v2>

  <blendMode>0</blendMode>
</qgis>
