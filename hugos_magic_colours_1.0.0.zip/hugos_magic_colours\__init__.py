def classFactory(iface):
    from .magic_colours_plugin import MagicColoursPlugin
    return MagicColoursPlugin(iface)
